document.addEventListener("DOMContentLoaded",()=> {
  const form=qs("#contactForm");if(!form)return;form.addEventListener("submit",e=> {
    e.preventDefault();const d=getData(),fd=new FormData(form);d.tickets.unshift( {
      id:uid("tk-"),type:String(fd.get("type")||"care"),name:String(fd.get("name")||"Khách hàng"),contact:String(fd.get("contact")||""),subject:String(fd.get("subject")||"Liên hệ"),message:String(fd.get("message")||""),status:"Mới",createdAt:today()
    });saveData(d);addActivity(`${String(fd.get("name")||"Khách hàng")} gửi yêu cầu chăm sóc`);qs("#contactMessage").textContent="Đã ghi nhận yêu cầu. Trung tâm sẽ liên hệ lại.";form.reset()
  })
});
