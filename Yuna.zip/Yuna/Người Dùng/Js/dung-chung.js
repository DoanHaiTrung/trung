const MK = {
  data: "yuna_data_v8",
  accounts: "yuna_accounts_v8",
  user: "yuna_user_v8",
  login: "yuna_login_v8",
  pending: "yuna_pending_course_v8",
  pendingTest: "mermaid_pending_test_v1"
};

const ROLE_NAME = {
  admin: "Quản trị viên",
  staff: "Nhân viên",
  accountant: "Kế toán",
  teacher: "Giáo viên",
  student: "Học viên"
};

const PERMISSIONS = [
  ["dashboard", "Tổng quan"],
  ["students", "Học viên"],
  ["teachers", "Giáo viên"],
  ["courses", "Khóa học"],
  ["classes", "Lớp học"],
  ["rooms", "Phòng học"],
  ["attendance", "Điểm danh"],
  ["leave", "Đơn nghỉ"],
  ["tests", "Tạo test"],
  ["results", "Kết quả test"],
  ["care", "Chăm sóc KH"],
  ["complaints", "Khiếu nại"],
  ["staff", "Quản lý NV"],
  ["payroll", "Tính lương"],
  ["accounts", "Tài khoản"],
  ["permissions", "Phân quyền"],
  ["loginHistory", "Lịch sử đăng nhập"],
  ["reports", "Biểu đồ & báo cáo"]
];

function qs(selector, parent = document) {
  return parent.querySelector(selector);
}

function qsa(selector, parent = document) {
  return [...parent.querySelectorAll(selector)];
}

function uid(prefix = "id") {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function money(value) {
  return new Intl.NumberFormat("vi-VN").format(Number(value) || 0) + "đ";
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function fmtDate(value) {
  if (!value) return "—";

  const date = new Date(value + "T00:00:00");
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("vi-VN");
}

function esc(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function roleName(role) {
  return ROLE_NAME[role] || role;
}

function seedData() {
  return {
    // Khóa học dùng chung trên website
    courses: [
      {
        id: "c-eng",
        name: "Tiếng Anh Giao Tiếp",
        language: "Tiếng Anh",
        level: "Cơ bản",
        duration: "3 tháng",
        durationGroup: "1-3",
        format: "Offline",
        certificate: true,
        certificateName: "Chứng nhận Yuna",
        price: 3200000,
        schedule: "T2 · T4 · T6 | 18:30 - 20:00",
        image: "../../IMG/course-english.png",
        desc: "Phát âm, phản xạ và giao tiếp thực tế.",
        active: true
      },
      {
        id: "c-kor",
        name: "Tiếng Hàn Sơ cấp",
        language: "Tiếng Hàn",
        level: "Cơ bản",
        duration: "4 tháng",
        durationGroup: "3-6",
        format: "Online",
        certificate: true,
        certificateName: "Chứng nhận hoàn thành",
        price: 4200000,
        schedule: "T3 · T5 | 19:00 - 20:30",
        image: "../../IMG/course-korean.png",
        desc: "Học bảng chữ cái, phát âm và hội thoại.",
        active: true
      },
      {
        id: "c-chn",
        name: "Tiếng Trung Chuyên sâu",
        language: "Tiếng Trung",
        level: "Trung cấp",
        duration: "5 tháng",
        durationGroup: "3-6",
        format: "Offline",
        certificate: true,
        certificateName: "Lộ trình HSK",
        price: 4800000,
        schedule: "T2 · T4 · T6 | 19:00 - 20:30",
        image: "../../IMG/course-chinese.png",
        desc: "Nghe, nói, đọc, viết và luyện HSK.",
        active: true
      },
      {
        id: "c-jpn",
        name: "Tiếng Nhật N5–N4",
        language: "Tiếng Nhật",
        level: "Cơ bản",
        duration: "5 tháng",
        durationGroup: "3-6",
        format: "Offline",
        certificate: true,
        certificateName: "Luyện thi JLPT",
        price: 3500000,
        schedule: "T3 · T5 · T7 | 18:30 - 20:00",
        image: "../../IMG/course-japanese.png",
        desc: "Kana, ngữ pháp, hội thoại và JLPT.",
        active: true
      },
      {
        id: "c-eng2",
        name: "Tiếng Anh Công Sở",
        language: "Tiếng Anh",
        level: "Trung cấp",
        duration: "6 tháng",
        durationGroup: "3-6",
        format: "Online",
        certificate: true,
        certificateName: "Chứng nhận Yuna",
        price: 5600000,
        schedule: "T2 · T4 | 20:00 - 21:30",
        image: "../../IMG/course-english.png",
        desc: "Email, họp, thuyết trình và giao tiếp công sở.",
        active: true
      },
      {
        id: "c-topik",
        name: "Luyện TOPIK II",
        language: "Tiếng Hàn",
        level: "Nâng cao",
        duration: "8 tháng",
        durationGroup: "6-9",
        format: "Hybrid",
        certificate: false,
        certificateName: "",
        price: 6500000,
        schedule: "T7 · CN | 08:30 - 10:00",
        image: "../../IMG/course-korean.png",
        desc: "Luyện đọc, viết, từ vựng và chiến lược TOPIK.",
        active: true
      }
    ],

    // Dữ liệu nghiệp vụ được tạo từ trang quản trị
    teachers: [],
    students: [],
    classes: [],
    rooms: [],
    enrollments: [],
    attendance: [],
    leaveRequests: [],
    payroll: [],
    loginHistory: [],
    tests: [],
    testResults: [],
    tickets: [],
    staff: [],
    notifications: [],
    activity: []
  };
}

function getData() {
  try {
    const raw = localStorage.getItem(MK.data);

    if (!raw) {
      const data = seedData();
      saveData(data);
      return data;
    }

    const data = JSON.parse(raw);

    data.staff = (data.staff || []).map(staff => ({
      baseSalary: 8000000,
      allowance: 0,
      deduction: 0,
      ...staff
    }));
    data.payroll = Array.isArray(data.payroll) ? data.payroll : [];
    data.loginHistory = Array.isArray(data.loginHistory)
      ? data.loginHistory
      : [];

    saveData(data);
    return data;
  } catch (error) {
    const data = seedData();
    saveData(data);
    return data;
  }
}

function saveData(data) {
  localStorage.setItem(MK.data, JSON.stringify(data));
}

function getAccounts() {
  try {
    return JSON.parse(localStorage.getItem(MK.accounts) || "[]");
  } catch (error) {
    return [];
  }
}

function saveAccounts(accounts) {
  localStorage.setItem(MK.accounts, JSON.stringify(accounts));
}

function seedAccounts() {
  const admin = {
    email: "admin@gmail.com",
    password: "Mduyen952004",
    name: "Vũ Thị Mỹ Duyên",
    role: "admin"
  };

  const accounts = getAccounts();

  if (!accounts.length) {
    saveAccounts([admin]);
    return;
  }

  const hasAdmin = accounts.some(account =>
    String(account.email).toLowerCase() === admin.email
  );

  if (!hasAdmin) {
    accounts.unshift(admin);
    saveAccounts(accounts);
  }
}

function currentUser() {
  try {
    return JSON.parse(localStorage.getItem(MK.user) || "null");
  } catch (error) {
    return null;
  }
}

function setUser(user) {
  localStorage.setItem(MK.user, JSON.stringify(user));
  localStorage.setItem(MK.login, "1");
}

function clearUser() {
  localStorage.removeItem(MK.user);
  localStorage.removeItem(MK.login);
}

function isLogged() {
  return Boolean(currentUser()) && localStorage.getItem(MK.login) === "1";
}

function courseById(id) {
  return getData().courses.find(item => item.id === id) || null;
}

function classById(id) {
  return getData().classes.find(item => item.id === id) || null;
}

function teacherById(id) {
  return getData().teachers.find(item => item.id === id) || null;
}

function studentById(id) {
  return getData().students.find(item => item.id === id) || null;
}

function myEnrollments(studentId) {
  return getData().enrollments.filter(
    item => item.studentId === studentId && item.status !== "cancelled"
  );
}

function hasEnrollment(studentId) {
  return myEnrollments(studentId).length > 0;
}

function updateEnrollmentProgress(data, classId) {
  if (!classId) return;

  const classAttendance = data.attendance.filter(
    record => record.classId === classId
  );

  const studentIds = new Set(
    classAttendance.map(record => record.studentId)
  );

  studentIds.forEach(studentId => {
    const enrollment = data.enrollments.find(item =>
      item.classId === classId &&
      item.studentId === studentId &&
      item.status !== "cancelled"
    );

    if (!enrollment) return;

    const records = classAttendance.filter(
      record => record.studentId === studentId
    );

    const attended = records.filter(record =>
      ["present", "late"].includes(record.status)
    ).length;

    enrollment.progress = records.length
      ? Math.round((attended / records.length) * 100)
      : 0;
  });
}

function goToLoginForTest() {
  localStorage.setItem(MK.pendingTest, "1");
  location.href = "index.html#account";
}

function studentHasNotification(studentId, notice) {
  return (
    notice.audience === "all" ||
    (notice.audience === "student" && !notice.targetId) ||
    (notice.audience === "student" && notice.targetId === studentId)
  );
}

function addLoginHistory(action, account = currentUser()) {
  if (!account) return;

  const data = getData();

  data.loginHistory.unshift({
    id: uid("login-"),
    name: account.name || "—",
    email: account.email || "—",
    role: account.role || "—",
    action,
    time: new Date().toISOString()
  });

  data.loginHistory = data.loginHistory.slice(0, 200);
  saveData(data);
}

function addActivity(text) {
  const data = getData();
  data.activity.unshift(text);
  data.activity = data.activity.slice(0, 60);
  saveData(data);
}

function addNotice(title, content, audience = "all", targetId = "") {
  const data = getData();
  data.notifications.unshift({
    id: uid("n-"),
    title,
    content,
    audience,
    targetId,
    createdAt: today()
  });
  saveData(data);
}

function showWelcomeToast() {
  const name = currentUser()?.name || "bạn";
  const old = qs("#yunaWelcomeToast");
  if (old) old.remove();

  const toast = document.createElement("div");
  toast.id = "yunaWelcomeToast";
  toast.className = "yuna-welcome-toast";
  toast.innerHTML = `
    <strong>Chào mừng trở lại Yuna</strong>
    <span>Xin chào ${esc(name)}. Chúc bạn có một buổi học hiệu quả!</span>`;

  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add("show"), 20);
  setTimeout(() => toast.classList.remove("show"), 4200);
  setTimeout(() => toast.remove(), 4700);
}

function buildHeader() {
  const host = qs("#header");

  if (!host) return;

  const page = location.pathname.split("/").pop() || "index.html";
  const user = currentUser();

  let accountButton = `
    <button class="header-account" type="button" data-open-account="login">
      👤 Đăng nhập / Đăng ký
    </button>`;

  if (user) {
    const links = [
      `<a href="thong-tin-hoc-vien.html">👤 Thông tin cá nhân</a>`
    ];

    if (user.role === "student" && hasEnrollment(user.studentId)) {
      links.push(
        `<a href="khoa-hoc-cua-toi.html">📚 Khóa học của tôi</a>`,
        `<a href="lich-hoc.html">📅 Theo dõi lịch học</a>`,
        `<a href="thong-bao.html">🔔 Thông báo</a>`,
        `<a href="xin-nghi.html">📝 Xin nghỉ / Đơn mẫu</a>`
      );
    }

    if (user.role === "teacher") {
      links.push(
        `<a href="giao-vien.html">🧑‍🏫 Trang giáo viên</a>`,
        `<a href="lich-day.html">📅 Lịch dạy</a>`,
        `<a href="diem-danh.html">✅ Điểm danh</a>`,
        `<a href="theo-doi-hoc-sinh.html">📈 Theo dõi học sinh</a>`,
        `<a href="xin-nghi.html">📝 Xin nghỉ / Đơn mẫu</a>`
      );
    }

    if (["admin", "staff", "accountant"].includes(user.role)) {
      links.push(`<a href="../../Quan Tri/quan-tri.html">⚙ Khu vực quản trị</a>`);
    }

    accountButton = `
      <div class="account-user-wrap">
        <button class="header-user-button" id="headerUserButton" type="button">
          <span class="user-avatar">${esc((user.name || "M")[0].toUpperCase())}</span>
          <span class="user-name">${esc(user.name)}</span>
          <span>⌄</span>
        </button>

        <button class="header-logout" id="headerLogout" type="button">
          Đăng xuất
        </button>

        <div class="user-dropdown" id="userDropdown">
          <div class="user-dropdown-head">
            <strong>${esc(user.name)}</strong>
            <small>${esc(roleName(user.role))}</small>
          </div>
          ${links.join("")}
          <button class="user-dropdown-logout" id="dropdownLogout" type="button">
            Đăng xuất
          </button>
        </div>
      </div>`;
  }

  const active = file => page === file ? "active" : "";

  host.innerHTML = `
    <header class="site-header">
      <div class="header-inner">
        <a class="brand" href="index.html">
          <span class="brand-avatar">
            <img src="../../IMG/logo-merimaid.jpg" alt="Yuna Language Center">
          </span>
          <span class="brand-name">
            <strong>YUNA</strong>
            <small>LANGUAGE CENTER</small>
          </span>
        </a>

        <nav class="main-nav" id="mainNav">
          <a class="${active("index.html")}" href="index.html">Trang chủ</a>
          <a class="${active("khoa-hoc.html")}" href="khoa-hoc.html">Khóa học</a>
          <a class="${active("gioi-thieu.html")}" href="gioi-thieu.html">Giới thiệu</a>
          <a class="${active("bai-test.html")}" href="bai-test.html">Bài test</a>
          <a class="${active("lien-he.html")}" href="lien-he.html">Liên hệ</a>
        </nav>

        <div class="header-right">
          ${accountButton}
        </div>

        <button class="menu-btn" id="menuBtn" type="button">☰</button>
      </div>
    </header>`;

  qs("#menuBtn")?.addEventListener("click", () => {
    qs("#mainNav")?.classList.toggle("open");
  });

  qs("#headerUserButton")?.addEventListener("click", event => {
    event.stopPropagation();
    qs("#userDropdown")?.classList.toggle("open");
  });

  qs("#headerLogout")?.addEventListener("click", () => {
    window.AccountUI?.logout();
  });

  qs("#dropdownLogout")?.addEventListener("click", () => {
    window.AccountUI?.logout();
  });

  if (!window.__mermaidHeaderClickBound) {
    document.addEventListener("click", event => {
      if (!event.target.closest(".account-user-wrap")) {
        qs("#userDropdown")?.classList.remove("open");
      }
    });

    window.__mermaidHeaderClickBound = true;
  }
}

function buildFooter() {
  const footer = qs("#footer");

  if (!footer) return;

  footer.innerHTML = `
    <footer class="site-footer">
      <div class="footer-inner">
        <div>
          <h3>YUNA</h3>
          <p>
            Trung tâm ngoại ngữ phong cách đại dương, đồng hành cùng bạn trên hành trình chinh phục ngôn ngữ.
          </p>
        </div>

        <div>
          <h3>Khám phá</h3>
          <a href="khoa-hoc.html">Khóa học</a>
          <a href="bai-test.html">Bài test</a>
          <a href="gioi-thieu.html">Giới thiệu</a>
        </div>

        <div>
          <h3>Liên hệ</h3>
          <p>0900 123 456<br>hello@mermaid.vn</p>
          <a href="lien-he.html">Gửi yêu cầu tư vấn →</a>
        </div>
      </div>

      <div class="footer-bottom">© 2026 Yuna Language Center</div>
    </footer>`;
}

document.addEventListener("DOMContentLoaded", () => {
  seedAccounts();
  getData();
  buildHeader();
  buildFooter();

  if (sessionStorage.getItem("yuna_welcome_toast") === "1") {
    sessionStorage.removeItem("yuna_welcome_toast");
    showWelcomeToast();
  }
});
