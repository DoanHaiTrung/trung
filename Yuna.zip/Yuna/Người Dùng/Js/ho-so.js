document.addEventListener("DOMContentLoaded",()=> {
  const root=qs("#profileArea");if(!root)return;const user=currentUser();if(!user) {
    location.href="index.html#account";return
  }
  const d=getData();if(user.role==="student") {
    const s=studentById(user.studentId);if(!s) {
      root.innerHTML='<div class="notice-inline">Không tìm thấy hồ sơ học viên.</div>';return
    }
    root.innerHTML=`<div class="profile-grid">
<aside class="profile-card">
<div class="avatar-large">${esc((s.name||"M")[0].toUpperCase())}</div>
<h2>${esc(s.name)}</h2>
<p>${esc(s.email)}<br>${esc(s.phone||"")}</p>
<div class="badge-row">
<span>Học viên</span>
<span>${hasEnrollment(s.id)?"Đang học":"Chưa đăng ký khóa"}</span>
</div>
</aside>
<form class="form-card" id="profileForm">
<div class="grid-2">
<label>Họ và tên<input name="name" value="${esc(s.name||"")}" required>
</label>
<label>Email<input value="${esc(s.email||"")}" readonly>
</label>
<label>Số điện thoại<input name="phone" value="${esc(s.phone||"")}">
</label>
<label>Ngày sinh<input name="dob" type="date" value="${esc(s.dob||"")}">
</label>
<label>Ngôn ngữ<input name="language" value="${esc(s.language||"Tiếng Anh")}">
</label>
<label>Mục tiêu<select name="goal">${["Giao tiếp","Luyện thi","Công việc","Du học"].map(v=>`<option ${s.goal===v?"selected":""}>${v}</option>`).join("")}</select>
</label>
</div>
<label>Địa chỉ<input name="address" value="${esc(s.address||"")}">
</label>
<label>Ghi chú<textarea name="note">${esc(s.note||"")}</textarea>
</label>
<button class="btn primary">Lưu thông tin</button>
<div id="profileMessage" class="message">
</div>
</form>
</div>`;qs("#profileForm").addEventListener("submit",e=> {
      e.preventDefault();const fd=new FormData(e.currentTarget);["name","phone","dob","language","goal","address","note"].forEach(k=>s[k]=String(fd.get(k)||""));s.status=hasEnrollment(s.id)?"Đang học":"Chưa đăng ký khóa học";saveData(d);setUser( {
        ...user,name:s.name
      });addActivity(`${s.name} cập nhật hồ sơ học viên`);qs("#profileMessage").textContent="Đã lưu thông tin cá nhân.";buildHeader()
    });return
  }
  if(user.role==="teacher") {
    const t=teacherById(user.teacherId),classes=d.classes.filter(c=>c.teacherId===user.teacherId),ens=d.enrollments.filter(e=>classes.some(c=>c.id===e.classId)&&e.status!=="cancelled");root.innerHTML=`<div class="profile-grid">
<aside class="profile-card">
<div class="avatar-large">${esc((user.name||"G")[0].toUpperCase())}</div>
<h2>${esc(user.name)}</h2>
<p>${esc(user.email)}<br>${esc(t?.phone||"")}</p>
<div class="badge-row">
<span>Giáo viên</span>
<span>${esc(t?.specialty||"")}</span>
</div>
</aside>
<div class="form-card">
<h2 style="color:#0b607c;margin-top:0">Thông tin giảng dạy</h2>
<div class="grid-2">
<div class="notice-inline">Lớp phụ trách: <b>${classes.length}</b>
</div>
<div class="notice-inline">Học viên theo dõi: <b>${ens.length}</b>
</div>
</div>
<p style="font-size:9px;color:#7c9ba5;line-height:1.7">Bạn đang sử dụng website chính. Từ menu tên tài khoản có thể mở lịch dạy, điểm danh, theo dõi học sinh và đơn xin nghỉ.</p>
</div>
</div>`;return
  }
  root.innerHTML=`<div class="notice-inline">Tài khoản ${esc(roleName(user.role))} sử dụng khu vực quản trị.</div>`
})
