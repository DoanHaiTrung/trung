
document.addEventListener("DOMContentLoaded", () => {
  const user = currentUser();

  if (!user || !["admin", "staff", "accountant"].includes(user.role)) {
    location.href = "../Người Dùng/html/index.html#account";
    return;
  }

  const nav = qs("#adminNav");
  const root = qs("#sectionsRoot");
  const modal = qs("#adminModal");

  let data = getData();

  const roleStaff = data.staff.find(item => item.id === user.staffId);
  const allowed = new Set(
    user.role === "admin"
      ? PERMISSIONS.map(item => item[0])
      : (roleStaff?.permissions || ["dashboard"]).filter(
          key => !["accounts", "permissions", "loginHistory"].includes(key)
        )
  );

  qs("#adminUser").textContent = `${user.name} · ${roleName(user.role)}`;

  buildNavigation();
  buildSections();
  bindBaseEvents();
  renderAll();

  showSection(
    allowed.has("dashboard")
      ? "dashboard"
      : PERMISSIONS.find(item => allowed.has(item[0]))?.[0]
  );

  function buildNavigation() {
    nav.innerHTML = PERMISSIONS
      .filter(([key]) => allowed.has(key) && key !== "permissions")
      .map(([key, label]) => `
        <button
          type="button"
          data-section="${key}"
        >
          ${icon(key)} ${label}
        </button>`)
      .join("");
  }

  function buildSections() {
    root.innerHTML = PERMISSIONS.map(([key]) =>
      `<section class="admin-section" id="section-${key}"></section>`
    ).join("");
  }

  function bindBaseEvents() {
    nav.addEventListener("click", event => {
      const button = event.target.closest("button[data-section]");

      if (!button || button.disabled) {
        return;
      }

      showSection(button.dataset.section);
    });

    qs("#backWebsite").addEventListener("click", () => {
      location.href = "../Người Dùng/html/index.html";
    });

    qs("#logoutAdmin").addEventListener("click", () => {
      const current = currentUser();

      clearUser();

      if (current) {
        addLoginHistory("Đăng xuất", current);
      }

      location.href = "../Người Dùng/html/index.html";
    });
  }

  function showSection(key) {
    if (!key || !allowed.has(key)) {
      return;
    }

    qsa(".admin-nav button").forEach(button => {
      button.classList.toggle("active", button.dataset.section === key);
    });

    qsa(".admin-section").forEach(section => {
      section.classList.remove("active");
    });

    qs(`#section-${key}`)?.classList.add("active");

    const permission = PERMISSIONS.find(item => item[0] === key);
    qs("#sectionTitle").textContent = permission?.[1] || "Quản trị";

    renderSection(key);
  }

  function renderAll() {
    PERMISSIONS.forEach(([key]) => {
      if (allowed.has(key)) {
        renderSection(key);
      }
    });
  }

  function renderSection(key) {
    data = getData();

    const host = qs(`#section-${key}`);

    if (!host || !allowed.has(key)) {
      return;
    }

    const renderer = {
      dashboard: renderDashboard,
      students: renderStudents,
      teachers: renderTeachers,
      courses: renderCourses,
      classes: renderClasses,
      rooms: renderRooms,
      attendance: renderAttendance,
      leave: renderLeave,
      tests: renderTests,
      results: renderResults,
      care: () => renderTickets("care"),
      complaints: () => renderTickets("complaint"),
      staff: renderStaff,
      payroll: renderPayroll,
      permissions: renderPermissions,
      accounts: renderAccounts,
      loginHistory: renderLoginHistory,
      reports: renderReports
    };

    renderer[key]?.(host);
  }

  function icon(key) {
    const icons = {
      dashboard: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/>',
      students: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M17 11a3 3 0 0 0 0-6M17 14a5 5 0 0 1 4 4"/>',
      teachers: '<circle cx="12" cy="7" r="3"/><path d="M5 21a7 7 0 0 1 14 0M17 4l3 2-2 2"/>',
      courses: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21z"/><path d="M4 5.5V21M8 7h8M8 11h8"/>',
      classes: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/>',
      rooms: '<path d="M5 21V4h14v17M5 8h14M9 21v-4h6v4"/>',
      attendance: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
      leave: '<path d="M6 3h12v18H6z"/><path d="M9 7h6M9 11h6M9 15h4"/>',
      tests: '<path d="M6 3h12v18H6z"/><path d="m9 8 1.5 1.5L14 6M9 13h6M9 17h6"/>',
      results: '<path d="M5 19V9M12 19V5M19 19v-8"/><path d="M3 19h18"/>',
      care: '<path d="M5 5h14v11H8l-3 3z"/><path d="M8 9h8M8 12h5"/>',
      complaints: '<path d="M12 4 21 20H3z"/><path d="M12 9v5M12 17h.01"/>',
      staff: '<circle cx="8" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20a5 5 0 0 1 10 0M14 20a4 4 0 0 1 7 0"/>',
      payroll: '<rect x="4" y="6" width="16" height="13" rx="2"/><path d="M8 10h8M8 14h3"/><circle cx="16" cy="14" r="1.5"/>',
      permissions: '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
      accounts: '<circle cx="12" cy="8" r="3"/><path d="M5 21a7 7 0 0 1 14 0"/>',
      loginHistory: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      reports: '<path d="M5 20V10M12 20V5M19 20v-8"/><path d="M3 20h18"/>'
    };

    return `
      <span class="nav-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          ${icons[key] || '<circle cx="12" cy="12" r="3"/>'}
        </svg>
      </span>`;
  }

  function panel(title, body, note = "") {
    return `
      <div class="panel">
        <div class="panel-head">
          <div>
            <h2>${title}</h2>
            ${note ? `<div class="panel-sub">${note}</div>` : ""}
          </div>
        </div>
        ${body}
      </div>`;
  }

  function managementTools(host, fileName, placeholder = "Tìm kiếm...") {
    const table = qs(".data-table", host);

    if (!table) return;

    const wrap = qs(".table-wrap", host);
    if (!wrap) return;

    if (!qs(".management-tools", host)) {
      const tools = document.createElement("div");
      tools.className = "management-tools";
      tools.innerHTML = `
        <input type="search" placeholder="${esc(placeholder)}">
        <button class="admin-btn" type="button">Xuất Excel</button>`;
      wrap.before(tools);

      const search = qs("input", tools);
      search.addEventListener("input", () => {
        const keyword = search.value.trim().toLowerCase();

        qsa("tbody tr", table).forEach(row => {
          const text = row.textContent.toLowerCase();
          row.hidden = Boolean(keyword && !text.includes(keyword));
        });
      });

      qs("button", tools).addEventListener("click", () => {
        exportVisibleTable(table, fileName);
      });
    }
  }

  function exportVisibleTable(table, fileName) {
    const headers = qsa("thead th", table).map(th => th.textContent.trim());
    const rows = qsa("tbody tr", table)
      .filter(row => !row.hidden)
      .map(row => qsa("td", row).map(cell => cell.textContent.trim()));

    if (!rows.length) {
      alert("Không có dữ liệu đang hiển thị để xuất.");
      return;
    }

    exportRowsAsExcel(fileName, headers, rows);
  }

  function exportRowsAsExcel(fileName, headers, rows) {
    const escCell = value => String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");

    const table = `
      <table border="1">
        <thead>
          <tr>${headers.map(item => `<th>${escCell(item)}</th>`).join("")}</tr>
        </thead>
        <tbody>
          ${rows.map(row => `
            <tr>${row.map(item => `<td>${escCell(item)}</td>`).join("")}</tr>`).join("")}
        </tbody>
      </table>`;

    const html = `
      <html>
        <head><meta charset="UTF-8"></head>
        <body>${table}</body>
      </html>`;

    const blob = new Blob(["\ufeff", html], {
      type: "application/vnd.ms-excel;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `${fileName}.xls`;
    link.click();

    URL.revokeObjectURL(url);
  }
// Dashboard
  function renderDashboard(host) {
    const totalRevenue = data.enrollments.reduce((sum, enrollment) => {
      return sum + (courseById(enrollment.courseId)?.price || 0);
    }, 0);

    const complaints = data.tickets.filter(item => item.type === "complaint").length;

    host.innerHTML = `
      <div class="stats">
        ${statCard(data.students.length, "Học viên")}
        ${statCard(data.teachers.length, "Giáo viên")}
        ${statCard(data.courses.length, "Khóa học")}
        ${statCard(data.classes.length, "Lớp học")}
      </div>

      ${panel(
        "Tình hình vận hành",
        `
        <div class="cards-3">
          <div class="mini-card">
            <b>${data.enrollments.length}</b>
            <span>Lượt đăng ký khóa học</span>
          </div>
          <div class="mini-card">
            <b>${data.attendance.length}</b>
            <span>Bản ghi điểm danh</span>
          </div>
          <div class="mini-card">
            <b>${complaints}</b>
            <span>Khiếu nại cần theo dõi</span>
          </div>
        </div>
        `
      )}

      ${panel(
        "Giá trị đăng ký",
        `<div class="access-note">
          Tổng giá trị khóa học đã đăng ký trong bản demo:
          <b>${money(totalRevenue)}</b>
        </div>`
      )}

      ${panel(
        "Hoạt động gần đây",
        `
        <div class="activity-list">
          ${
            data.activity.length
              ? data.activity.slice(0, 15).map(item =>
                  `<div class="activity-item">${esc(item)}</div>`
                ).join("")
              : `<div class="empty-admin">Chưa có hoạt động.</div>`
          }
        </div>
        `
      )}

      ${panel(
        "Quyền của tài khoản hiện tại",
        `
        <div class="access-note">
          ${[...allowed]
            .map(key => PERMISSIONS.find(item => item[0] === key)?.[1] || key)
            .join(" · ")}
        </div>`
      )}`;
  }

  function statCard(value, label) {
    return `
      <div class="stat">
        <b>${value}</b>
        <span>${label}</span>
      </div>`;
  }
// Students
  function renderStudents(host) {
    host.innerHTML = panel(
      "Quản lý học viên",
      `
      <div class="toolbar">
        <input id="studentSearch" placeholder="Tìm tên, email, số điện thoại">
        <button class="admin-btn" id="studentRefresh">Làm mới</button>
        <button class="admin-btn" id="studentExport">Xuất Excel</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Học viên</th>
              <th>Liên hệ</th>
              <th>Ngôn ngữ</th>
              <th>Khóa</th>
              <th>Trạng thái</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody id="studentRows">${studentRows(data.students)}</tbody>
        </table>
      </div>`
    );

    qs("#studentSearch")?.addEventListener("input", event => {
      const keyword = event.target.value.toLowerCase();

      const filtered = data.students.filter(student =>
        `${student.name} ${student.email} ${student.phone}`
          .toLowerCase()
          .includes(keyword)
      );

      qs("#studentRows").innerHTML = studentRows(filtered);
      bindStudentActions(host);
    });

    qs("#studentRefresh")?.addEventListener("click", () => {
      renderSection("students");
    });

    qs("#studentExport")?.addEventListener("click", () => {
      exportVisibleTable(qs(".data-table", host), "hoc-vien");
    });

    bindStudentActions(host);
  }

  function studentRows(students) {
    if (!students.length) {
      return `
        <tr>
          <td colspan="6">
            <div class="empty-admin">Chưa có học viên.</div>
          </td>
        </tr>`;
    }

    return students.map(student => {
      const courseCount = myEnrollments(student.id).length;

      return `
        <tr>
          <td>
            <b>${esc(student.name)}</b><br>
            <span class="muted">${esc(student.email)}</span>
          </td>
          <td>${esc(student.phone || "—")}</td>
          <td>${esc(student.language || "—")}</td>
          <td>${courseCount}</td>
          <td>
            <span class="pill ${student.status === "Đang học" ? "green" : "gray"}">
              ${esc(student.status || "—")}
            </span>
          </td>
          <td>
            <div class="actions">
              <button class="admin-btn" data-student-edit="${student.id}">Sửa</button>
              <button class="admin-btn" data-student-enroll="${student.id}">
                Đăng ký khóa
              </button>
            </div>
          </td>
        </tr>`;
    }).join("");
  }

  function bindStudentActions(host) {
    qsa("[data-student-edit]", host).forEach(button => {
      button.addEventListener("click", () => {
        studentModal(button.dataset.studentEdit);
      });
    });

    qsa("[data-student-enroll]", host).forEach(button => {
      button.addEventListener("click", () => {
        enrollModal(button.dataset.studentEnroll);
      });
    });
  }
// Teachers
  function renderTeachers(host) {
    host.innerHTML = panel(
      "Quản lý giáo viên",
      `
      <div style="margin-bottom:11px">
        <button class="admin-btn primary" id="addTeacher">+ Thêm giáo viên</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Giáo viên</th>
              <th>Chuyên môn</th>
              <th>Liên hệ</th>
              <th>Lớp</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            ${data.teachers.map(teacher => `
              <tr>
                <td>
                  <b>${esc(teacher.name)}</b><br>
                  <span class="muted">${esc(teacher.email)}</span>
                </td>
                <td>${esc(teacher.specialty || "—")}</td>
                <td>${esc(teacher.phone || "—")}</td>
                <td>
                  ${data.classes.filter(item => item.teacherId === teacher.id).length}
                </td>
                <td>
                  <button class="admin-btn" data-edit-teacher="${teacher.id}">
                    Sửa
                  </button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>`
    );

    qs("#addTeacher")?.addEventListener("click", () => {
      teacherModal();
    });

    qsa("[data-edit-teacher]", host).forEach(button => {
      button.addEventListener("click", () => {
        teacherModal(button.dataset.editTeacher);
      });
    });

    managementTools(host, "giao-vien", "Tìm tên, email, chuyên môn...");
  }
// Courses
  function renderCourses(host) {
    host.innerHTML = panel(
      "Quản lý khóa học",
      `
      <div style="margin-bottom:11px">
        <button class="admin-btn primary" id="addCourse">+ Thêm khóa học</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Khóa học</th>
              <th>Ngôn ngữ</th>
              <th>Thời lượng</th>
              <th>Hình thức</th>
              <th>Chứng chỉ</th>
              <th>Học phí</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            ${data.courses.map(course => `
              <tr>
                <td>
                  <b>${esc(course.name)}</b><br>
                  <span class="muted">${esc(course.level)}</span>
                </td>
                <td>${esc(course.language)}</td>
                <td>${esc(course.duration)}</td>
                <td><span class="pill">${esc(course.format)}</span></td>
                <td>
                  ${course.certificate
                    ? esc(course.certificateName || "Có")
                    : "Không"}
                </td>
                <td>${money(course.price)}</td>
                <td>
                  <div class="actions">
                    <button class="admin-btn" data-edit-course="${course.id}">
                      Sửa
                    </button>
                    <button class="admin-btn danger" data-delete-course="${course.id}">
                      Xóa
                    </button>
                  </div>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>`
    );

    qs("#addCourse")?.addEventListener("click", () => courseModal());

    qsa("[data-edit-course]", host).forEach(button => {
      button.addEventListener("click", () => {
        courseModal(button.dataset.editCourse);
      });
    });

    qsa("[data-delete-course]", host).forEach(button => {
      button.addEventListener("click", () => {
        if (!confirm("Xóa khóa học này?")) {
          return;
        }

        data.courses = data.courses.filter(
          course => course.id !== button.dataset.deleteCourse
        );

        saveData(data);
        addActivity("Quản trị viên xóa một khóa học");
        renderSection("courses");
      });
    });

    managementTools(host, "khoa-hoc", "Tìm tên khóa, ngôn ngữ, hình thức...");
  }
// Classes
  function renderClasses(host) {
    host.innerHTML = panel(
      "Quản lý lớp học",
      `
      <div style="margin-bottom:11px">
        <button class="admin-btn primary" id="addClass">+ Thêm lớp</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Lớp</th>
              <th>Khóa học</th>
              <th>Giáo viên</th>
              <th>Phòng</th>
              <th>Lịch</th>
              <th>Sĩ số</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            ${data.classes.map(classItem => {
              const total = data.enrollments.filter(
                enrollment =>
                  enrollment.classId === classItem.id &&
                  enrollment.status !== "cancelled"
              ).length;

              return `
                <tr>
                  <td><b>${esc(classItem.name)}</b></td>
                  <td>${esc(courseById(classItem.courseId)?.name || "—")}</td>
                  <td>${esc(teacherById(classItem.teacherId)?.name || "Chưa có")}</td>
                  <td>${esc(classItem.room || "—")}</td>
                  <td>${esc(classItem.schedule || "—")}</td>
                  <td>${total}/${classItem.capacity}</td>
                  <td>
                    <button class="admin-btn" data-edit-class="${classItem.id}">
                      Sửa
                    </button>
                  </td>
                </tr>`;
            }).join("")}
          </tbody>
        </table>
      </div>`
    );

    qs("#addClass")?.addEventListener("click", () => classModal());

    qsa("[data-edit-class]", host).forEach(button => {
      button.addEventListener("click", () => {
        classModal(button.dataset.editClass);
      });
    });

    managementTools(host, "lop-hoc", "Tìm lớp, khóa học, giáo viên, phòng...");
  }
// Rooms
  function renderRooms(host) {
    host.innerHTML = panel(
      "Quản lý phòng học",
      `
      <div style="margin-bottom:11px">
        <button class="admin-btn primary" id="addRoom">+ Thêm phòng</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Phòng</th>
              <th>Sức chứa</th>
              <th>Vị trí</th>
              <th>Thiết bị</th>
              <th>Trạng thái</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${data.rooms.map(room => `
              <tr>
                <td><b>${esc(room.name)}</b></td>
                <td>${room.capacity}</td>
                <td>${esc(room.location)}</td>
                <td>${esc(room.equipment)}</td>
                <td><span class="pill">${esc(room.status)}</span></td>
                <td>
                  <button class="admin-btn" data-edit-room="${room.id}">
                    Sửa
                  </button>
                </td>
              </tr>`
            ).join("")}
          </tbody>
        </table>
      </div>`
    );

    qs("#addRoom")?.addEventListener("click", () => roomModal());

    qsa("[data-edit-room]", host).forEach(button => {
      button.addEventListener("click", () => {
        roomModal(button.dataset.editRoom);
      });
    });

    managementTools(host, "phong-hoc", "Tìm tên phòng, vị trí, thiết bị...");
  }
// Attendance
  function renderAttendance(host) {
    const rows = data.classes.map(classItem => {
      const records = data.attendance.filter(
        record => record.classId === classItem.id
      );

      const present = records.filter(record =>
        ["present", "late"].includes(record.status)
      ).length;

      const absent = records.filter(
        record => record.status === "absent"
      ).length;

      const excused = records.filter(
        record => record.status === "excused"
      ).length;

      return `
        <tr>
          <td>${esc(classItem.name)}</td>
          <td>${records.length}</td>
          <td>${present}</td>
          <td>${absent}</td>
          <td>${excused}</td>
          <td>
            <button class="admin-btn" data-att-class="${classItem.id}">
              Xem chi tiết
            </button>
          </td>
        </tr>`;
    }).join("");

    host.innerHTML = panel(
      "Điểm danh",
      `
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Lớp</th>
              <th>Bản ghi</th>
              <th>Có mặt</th>
              <th>Vắng</th>
              <th>Có phép</th>
              <th></th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>

      <div id="attendanceDetail" style="margin-top:12px"></div>`
    );

    managementTools(host, "diem-danh", "Tìm tên lớp...");

    qsa("[data-att-class]", host).forEach(button => {
      button.addEventListener("click", () => {
        const classItem = classById(button.dataset.attClass);

        const records = data.attendance.filter(
          record => record.classId === classItem.id
        );

        qs("#attendanceDetail", host).innerHTML = records.length
          ? `
            <div class="access-note">
              <b>${esc(classItem.name)}</b><br>
              ${records.map(record => `
                ${fmtDate(record.date)}
                · ${esc(studentById(record.studentId)?.name || "—")}
                · <span class="pill">${esc(record.status)}</span>
                <br>`
              ).join("")}
            </div>`
          : `<div class="empty-admin">Chưa có dữ liệu điểm danh.</div>`;
      });
    });
  }

  // LEAVE REQUESTS
  function renderLeave(host) {
    const rows = data.leaveRequests;

    host.innerHTML = panel(
      "Đơn xin nghỉ / đổi lịch",
      `
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Người gửi</th>
              <th>Loại</th>
              <th>Ngày</th>
              <th>Nội dung</th>
              <th>Trạng thái</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            ${
              rows.length
                ? rows.map(request => {
                    const name = request.requesterRole === "student"
                      ? studentById(request.requesterId)?.name
                      : teacherById(request.requesterId)?.name;

                    const ref = request.requesterRole === "student"
                      ? courseById(
                          data.enrollments.find(
                            item => item.id === request.courseOrClassId
                          )?.courseId
                        )?.name
                      : classById(request.courseOrClassId)?.name;

                    return `
                      <tr>
                        <td>
                          <b>${esc(name || "—")}</b><br>
                          <span class="muted">${roleName(request.requesterRole)}</span>
                        </td>
                        <td>${esc(request.type)}</td>
                        <td>${fmtDate(request.date)}</td>
                        <td style="white-space:normal;min-width:250px">
                          ${esc(request.reason)}
                          <br><span class="muted">${esc(ref || "")}</span>
                        </td>
                        <td>
                          <span class="pill">${esc(request.status)}</span>
                        </td>
                        <td>
                          <div class="actions">
                            ${
                              request.status === "Chờ duyệt"
                                ? `
                                  <button class="admin-btn success"
                                    data-leave-approve="${request.id}">
                                    Duyệt
                                  </button>
                                  <button class="admin-btn danger"
                                    data-leave-reject="${request.id}">
                                    Từ chối
                                  </button>`
                                : ""
                            }
                          </div>
                        </td>
                      </tr>`;
                  }).join("")
                : `<tr><td colspan="6"><div class="empty-admin">Chưa có đơn nghỉ.</div></td></tr>`
            }
          </tbody>
        </table>
      </div>`
    );

    qsa("[data-leave-approve]", host).forEach(button => {
      button.addEventListener("click", () => {
        updateLeave(button.dataset.leaveApprove, "Đã duyệt");
      });
    });

    qsa("[data-leave-reject]", host).forEach(button => {
      button.addEventListener("click", () => {
        updateLeave(button.dataset.leaveReject, "Từ chối");
      });
    });

    managementTools(host, "don-nghi", "Tìm người gửi, loại, ngày, trạng thái...");
  }

  function updateLeave(id, status) {
    const request = data.leaveRequests.find(item => item.id === id);

    if (!request) {
      return;
    }

    request.status = status;
    saveData(data);
    addActivity(`${user.name} ${status.toLowerCase()} một đơn nghỉ`);
    renderSection("leave");
  }
// Tests
  function renderTests(host) {
    host.innerHTML = panel(
      "Tạo test & ngân hàng câu hỏi",
      `
      <div class="toolbar">
        <input id="testSearch" placeholder="Tìm tên bài test, ngôn ngữ, cấp độ">
        <button class="admin-btn primary" id="addTest">+ Tạo bài test</button>
        <button class="admin-btn" id="testExport">Xuất Excel</button>
      </div>

      <div class="cards-2" id="testCards">
        ${
          data.tests.length
            ? data.tests.map(test => `
              <div class="mini-card">
                <b>${esc(test.title)}</b>
                <span>
                  ${esc(test.language)}
                  · ${esc(test.level)}
                  · ${test.durationMinutes} phút
                  · ${test.questions.length} câu
                </span>
                <div style="margin-top:8px">
                  <button class="admin-btn" data-edit-test="${test.id}">
                    Chỉnh sửa
                  </button>
                  <button class="admin-btn danger" data-delete-test="${test.id}">
                    Xóa
                  </button>
                </div>
              </div>`
            ).join("")
            : `<div class="empty-admin">Chưa có bài test.</div>`
        }
      </div>`
    );

    qs("#addTest")?.addEventListener("click", () => testModal());

    qsa("[data-edit-test]", host).forEach(button => {
      button.addEventListener("click", () => {
        testModal(button.dataset.editTest);
      });
    });

    qsa("[data-delete-test]", host).forEach(button => {
      button.addEventListener("click", () => {
        if (!confirm("Xóa bài test này?")) {
          return;
        }

        data.tests = data.tests.filter(
          test => test.id !== button.dataset.deleteTest
        );

        saveData(data);
        renderSection("tests");
      });
    });

    qs("#testSearch", host)?.addEventListener("input", event => {
      const keyword = event.target.value.trim().toLowerCase();

      qsa(".mini-card", qs("#testCards", host)).forEach(card => {
        card.hidden = Boolean(keyword && !card.textContent.toLowerCase().includes(keyword));
      });
    });

    qs("#testExport", host)?.addEventListener("click", () => {
      const cards = qsa(".mini-card", qs("#testCards", host))
        .filter(card => !card.hidden);

      const rows = cards.map(card => {
        const test = data.tests.find(item =>
          card.querySelector("[data-edit-test]")?.dataset.editTest === item.id
        );

        return test
          ? [test.title, test.language, test.level, `${test.durationMinutes} phút`, test.questions.length]
          : [];
      }).filter(row => row.length);

      exportRowsAsExcel(
        "bai-test",
        ["Bài test", "Ngôn ngữ", "Cấp độ", "Thời lượng", "Số câu"],
        rows
      );
    });
  }
// Results
  function renderResults(host) {
    host.innerHTML = panel(
      "Kết quả test",
      `
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Học viên</th>
              <th>Bài test</th>
              <th>Điểm</th>
              <th>Ngày</th>
            </tr>
          </thead>
          <tbody>
            ${
              data.testResults.length
                ? data.testResults.map(result => `
                  <tr>
                    <td>${esc(studentById(result.studentId)?.name || "—")}</td>
                    <td>${esc(data.tests.find(test => test.id === result.testId)?.title || "—")}</td>
                    <td>
                      <span class="pill ${result.score >= 70 ? "green" : "red"}">
                        ${result.score}/100
                      </span>
                    </td>
                    <td>${fmtDate(result.createdAt)}</td>
                  </tr>`
                ).join("")
                : `<tr><td colspan="4"><div class="empty-admin">Chưa có kết quả test.</div></td></tr>`
            }
          </tbody>
        </table>
      </div>`
    );

    managementTools(host, "ket-qua-test", "Tìm học viên hoặc bài test...");
  }

  // CARE / COMPLAINTS
  function renderTickets(type) {
    const host = qs(`#section-${type === "care" ? "care" : "complaints"}`);
    const title = type === "care"
      ? "Chăm sóc khách hàng"
      : "Khiếu nại";

    const rows = data.tickets.filter(ticket => ticket.type === type);

    host.innerHTML = panel(
      title,
      `
      <div style="margin-bottom:11px">
        <button class="admin-btn primary" data-add-ticket="${type}">
          + Thêm phiếu
        </button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Khách hàng</th>
              <th>Chủ đề</th>
              <th>Nội dung</th>
              <th>Trạng thái</th>
              <th>Ngày</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${
              rows.length
                ? rows.map(ticket => `
                  <tr>
                    <td>
                      <b>${esc(ticket.name)}</b><br>
                      ${esc(ticket.contact)}
                    </td>
                    <td>${esc(ticket.subject)}</td>
                    <td style="white-space:normal;min-width:250px">
                      ${esc(ticket.message)}
                    </td>
                    <td><span class="pill">${esc(ticket.status)}</span></td>
                    <td>${fmtDate(ticket.createdAt)}</td>
                    <td>
                      <button
                        class="admin-btn ${["Đã liên hệ", "Hoàn tất", "Từ chối"].includes(ticket.status) ? "view-only" : ""}"
                        data-ticket-${["Đã liên hệ", "Hoàn tất", "Từ chối"].includes(ticket.status) ? "view" : "edit"}="${ticket.id}">
                        ${["Đã liên hệ", "Hoàn tất", "Từ chối"].includes(ticket.status) ? "Xem" : "Xử lý"}
                      </button>
                    </td>
                  </tr>`
                ).join("")
                : `<tr><td colspan="6"><div class="empty-admin">Chưa có phiếu.</div></td></tr>`
            }
          </tbody>
        </table>
      </div>`
    );

    qs(`[data-add-ticket="${type}"]`, host)?.addEventListener(
      "click",
      () => ticketModal(type)
    );

    qsa("[data-ticket-edit]", host).forEach(button => {
      button.addEventListener("click", () => {
        ticketModal(type, button.dataset.ticketEdit, false);
      });
    });

    qsa("[data-ticket-view]", host).forEach(button => {
      button.addEventListener("click", () => {
        ticketModal(type, button.dataset.ticketView, true);
      });
    });

    managementTools(
      host,
      type === "care" ? "cham-soc-khach-hang" : "khieu-nai",
      "Tìm khách hàng, chủ đề, trạng thái..."
    );
  }
// Staff
  function renderStaff(host) {
    host.innerHTML = panel(
      "Quản lý nhân viên",
      `
      <div style="margin-bottom:11px">
        <button class="admin-btn primary" id="addStaff">+ Thêm nhân viên</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Nhân viên</th>
              <th>Loại tài khoản</th>
              <th>Liên hệ</th>
              <th>Trạng thái</th>
              <th>Quyền được cấp</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            ${data.staff.map(staff => `
              <tr>
                <td>
                  <b>${esc(staff.name)}</b><br>
                  <span class="muted">${esc(staff.email)}</span>
                </td>
                <td>${esc(roleName(staff.role))}</td>
                <td>${esc(staff.phone || "—")}</td>
                <td><span class="pill green">${esc(staff.status)}</span></td>
                <td>
                  <div class="permission-summary">
                    ${(staff.permissions || [])
                      .map(key => PERMISSIONS.find(item => item[0] === key)?.[1])
                      .filter(Boolean)
                      .map(label => `<span class="permission-chip">${esc(label)}</span>`)
                      .join("") || `<span class="muted">Chưa cấp quyền</span>`}
                  </div>
                </td>
                <td>
                  <div class="actions">
                    <button class="admin-btn" data-edit-staff="${staff.id}">
                      Sửa
                    </button>
                    <button class="admin-btn" data-staff-permission="${staff.id}">
                      Quyền
                    </button>
                  </div>
                </td>
              </tr>`
            ).join("")}
          </tbody>
        </table>
      </div>`
    );

    qs("#addStaff")?.addEventListener("click", () => staffModal());

    qsa("[data-edit-staff]", host).forEach(button => {
      button.addEventListener("click", () => {
        staffModal(button.dataset.editStaff);
      });
    });

    qsa("[data-staff-permission]", host).forEach(button => {
      button.addEventListener("click", () => {
        permissionModal(button.dataset.staffPermission);
      });
    });

    managementTools(host, "nhan-vien", "Tìm tên, email, loại tài khoản...");
  }
// Payroll
  function renderPayroll(host) {
    const month = new Date().toISOString().slice(0, 7);
    const payrollRows = data.staff.map(staff => {
      const record = data.payroll.find(
        item => item.staffId === staff.id && item.month === month
      ) || {
        workDays: 26,
        allowance: Number(staff.allowance) || 0,
        deduction: Number(staff.deduction) || 0
      };

      const net = calculateSalary(staff, record);

      return `
        <tr data-payroll-row="${staff.id}">
          <td>
            <b>${esc(staff.name)}</b><br>
            <span class="muted">${esc(roleName(staff.role))}</span>
          </td>
          <td>${money(staff.baseSalary)}</td>
          <td>
            <input class="payroll-number" data-payroll-days value="${record.workDays}" min="0" max="31" type="number">
          </td>
          <td>
            <input class="payroll-number" data-payroll-allowance value="${record.allowance}" min="0" type="number">
          </td>
          <td>
            <input class="payroll-number" data-payroll-deduction value="${record.deduction}" min="0" type="number">
          </td>
          <td data-payroll-net>${money(net)}</td>
        </tr>`;
    }).join("");

    host.innerHTML = panel(
      "Tính lương nhân viên",
      `
      <div class="toolbar">
        <label>Tháng <input id="payrollMonth" type="month" value="${month}"></label>
        <button class="admin-btn primary" id="calculatePayroll">Tính lương</button>
      </div>

      <div class="access-note">
        Lương thực nhận = lương cơ bản × ngày công / 26 + phụ cấp − khấu trừ.
      </div>

      <div class="table-wrap">
        <table class="data-table" id="payrollTable">
          <thead>
            <tr>
              <th>Nhân viên</th>
              <th>Lương cơ bản</th>
              <th>Ngày công</th>
              <th>Phụ cấp</th>
              <th>Khấu trừ</th>
              <th>Thực nhận</th>
            </tr>
          </thead>
          <tbody>${payrollRows}</tbody>
        </table>
      </div>`
    );

    const table = qs("#payrollTable", host);

    const recalculate = () => {
      qsa("[data-payroll-row]", table).forEach(row => {
        const staff = data.staff.find(item => item.id === row.dataset.payrollRow);
        if (!staff) return;

        const record = {
          workDays: Number(qs("[data-payroll-days]", row)?.value) || 0,
          allowance: Number(qs("[data-payroll-allowance]", row)?.value) || 0,
          deduction: Number(qs("[data-payroll-deduction]", row)?.value) || 0
        };

        qs("[data-payroll-net]", row).textContent = money(
          calculateSalary(staff, record)
        );
      });
    };

    qsa(".payroll-number", host).forEach(input => {
      input.addEventListener("input", recalculate);
    });

    qs("#calculatePayroll", host)?.addEventListener("click", () => {
      const selectedMonth = qs("#payrollMonth", host).value || month;

      data.staff.forEach(staff => {
        const row = qs(`[data-payroll-row="${staff.id}"]`, host);
        if (!row) return;

        const record = {
          id: uid("pay-"),
          staffId: staff.id,
          month: selectedMonth,
          workDays: Number(qs("[data-payroll-days]", row).value) || 0,
          allowance: Number(qs("[data-payroll-allowance]", row).value) || 0,
          deduction: Number(qs("[data-payroll-deduction]", row).value) || 0
        };

        record.netSalary = calculateSalary(staff, record);

        data.payroll = data.payroll.filter(
          item => !(item.staffId === staff.id && item.month === selectedMonth)
        );
        data.payroll.push(record);
      });

      saveData(data);
      addActivity(`${user.name} đã tính lương tháng ${selectedMonth}`);
      renderSection("payroll");
    });

    managementTools(host, "bang-luong", "Tìm tên nhân viên, vai trò...");
  }

  function calculateSalary(staff, record) {
    const baseSalary = Number(staff.baseSalary) || 0;
    const workDays = Math.max(0, Math.min(31, Number(record.workDays) || 0));
    const allowance = Number(record.allowance) || 0;
    const deduction = Number(record.deduction) || 0;

    return Math.round((baseSalary / 26) * workDays + allowance - deduction);
  }

// Login history
  function renderLoginHistory(host) {
    if (user.role !== "admin") {
      return;
    }

    const rows = data.loginHistory.map(item => `
      <tr>
        <td>${esc(item.name)}</td>
        <td>${esc(item.email)}</td>
        <td>${esc(roleName(item.role))}</td>
        <td>${esc(item.action)}</td>
        <td>${new Date(item.time).toLocaleString("vi-VN")}</td>
      </tr>`).join("");

    host.innerHTML = panel(
      "Lịch sử đăng nhập",
      `
      <div class="access-note">
        Chỉ quản trị viên mới nhìn thấy lịch sử đăng nhập và đăng xuất.
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Họ tên</th>
              <th>Email</th>
              <th>Vai trò</th>
              <th>Hoạt động</th>
              <th>Thời gian</th>
            </tr>
          </thead>
          <tbody>
            ${rows || `<tr><td colspan="5"><div class="empty-admin">Chưa có lịch sử.</div></td></tr>`}
          </tbody>
        </table>
      </div>`
    );

    managementTools(host, "lich-su-dang-nhap", "Tìm tên, email, vai trò...");
  }

// Accounts
  function renderAccounts(host) {
    if (user.role !== "admin") {
      host.innerHTML = panel(
        "Tài khoản hệ thống",
        `<div class="access-note">
          Chỉ quản trị viên mới có quyền xem toàn bộ tài khoản trong hệ thống.
        </div>`
      );
      return;
    }

    const accounts = getAccounts();
    const studentsById = new Map(data.students.map(item => [item.id, item]));
    const teachersById = new Map(data.teachers.map(item => [item.id, item]));
    const staffById = new Map(data.staff.map(item => [item.id, item]));

    const accountRows = accounts.map(account => {
      let linked = "—";

      if (account.studentId) {
        const student = studentsById.get(account.studentId);
        linked = student ? `Học viên · ${esc(student.name)}` : "Học viên · Hồ sơ không còn tồn tại";
      } else if (account.teacherId) {
        const teacher = teachersById.get(account.teacherId);
        linked = teacher ? `Giáo viên · ${esc(teacher.name)}` : "Giáo viên · Hồ sơ không còn tồn tại";
      } else if (account.staffId) {
        const staff = staffById.get(account.staffId);
        linked = staff ? `${esc(roleName(staff.role))} · ${esc(staff.name)}` : "Nhân sự · Hồ sơ không còn tồn tại";
      } else if (account.role === "admin") {
        linked = "Quản trị hệ thống";
      }

      return `
        <tr>
          <td><b>${esc(account.name || "Chưa đặt tên")}</b></td>
          <td>${esc(account.email || "—")}</td>
          <td>
            <div class="account-password-cell">
              <input class="account-password" type="password" value="${esc(account.password || "")}" readonly aria-label="Mật khẩu tài khoản">
              <button type="button" class="admin-btn admin-btn-small account-password-toggle" data-password-toggle>Hiện</button>
            </div>
          </td>
          <td><span class="pill">${esc(roleName(account.role))}</span></td>
          <td>${linked}</td>
          <td><span class="pill green">Đang hoạt động</span></td>
        </tr>`;
    }).join("");

    host.innerHTML = panel(
      "Tất cả tài khoản",
      `
      <div class="toolbar">
        <input id="accountSearch" placeholder="Tìm tên hoặc email tài khoản">
        <select id="accountRoleFilter">
          <option value="all">Tất cả vai trò</option>
          ${Object.entries(ROLE_NAME).map(([key, label]) => `<option value="${esc(key)}">${esc(label)}</option>`).join("")}
        </select>
        <button class="admin-btn" id="accountRefresh">Làm mới</button>
        <button class="admin-btn" id="accountExport">Xuất Excel</button>
      </div>

      <div class="access-note" style="margin-bottom:14px">
        Tổng số tài khoản: <b>${accounts.length}</b>.
        Mật khẩu được lưu trong localStorage của bản demo. Quản trị viên có thể bấm “Hiện” để xem.
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Họ và tên</th>
              <th>Email / tài khoản</th>
              <th>Mật khẩu</th>
              <th>Vai trò</th>
              <th>Hồ sơ liên kết</th>
              <th>Trạng thái</th>
            </tr>
          </thead>
          <tbody id="accountRows">${accountRows || `<tr><td colspan="6"><div class="empty-admin">Chưa có tài khoản.</div></td></tr>`}</tbody>
        </table>
      </div>`
    );

    const renderFiltered = () => {
      const keyword = String(qs("#accountSearch")?.value || "").trim().toLowerCase();
      const role = qs("#accountRoleFilter")?.value || "all";
      const filtered = getAccounts().filter(account => {
        const matchText = `${account.name || ""} ${account.email || ""}`.toLowerCase().includes(keyword);
        const matchRole = role === "all" || account.role === role;
        return matchText && matchRole;
      });

      qs("#accountRows").innerHTML = filtered.length
        ? filtered.map(account => {
            let linked = "—";
            if (account.studentId) {
              const item = studentsById.get(account.studentId);
              linked = item ? `Học viên · ${esc(item.name)}` : "Học viên · Hồ sơ không còn tồn tại";
            } else if (account.teacherId) {
              const item = teachersById.get(account.teacherId);
              linked = item ? `Giáo viên · ${esc(item.name)}` : "Giáo viên · Hồ sơ không còn tồn tại";
            } else if (account.staffId) {
              const item = staffById.get(account.staffId);
              linked = item ? `${esc(roleName(item.role))} · ${esc(item.name)}` : "Nhân sự · Hồ sơ không còn tồn tại";
            } else if (account.role === "admin") {
              linked = "Quản trị hệ thống";
            }
            return `
              <tr>
                <td><b>${esc(account.name || "Chưa đặt tên")}</b></td>
                <td>${esc(account.email || "—")}</td>
                <td>Ẩn mật khẩu</td>
                <td><span class="pill">${esc(roleName(account.role))}</span></td>
                <td>${linked}</td>
                <td><span class="pill green">Đang hoạt động</span></td>
              </tr>`;
          }).join("")
        : `<tr><td colspan="6"><div class="empty-admin">Không tìm thấy tài khoản phù hợp.</div></td></tr>`;
    };

    qs("#accountSearch")?.addEventListener("input", renderFiltered);
    qs("#accountRoleFilter")?.addEventListener("change", renderFiltered);
    qs("#accountRefresh")?.addEventListener("click", () => renderSection("accounts"));
    qs("#accountExport")?.addEventListener("click", () => {
      exportVisibleTable(qs(".data-table", host), "tai-khoan");
    });
    qs("#accountRows")?.addEventListener("click", (event) => {
      const button = event.target.closest("[data-password-toggle]");
      if (!button) return;
      const input = button.parentElement?.querySelector(".account-password");
      if (!input) return;
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      button.textContent = show ? "Ẩn" : "Hiện";
    });
  }
// Permissions
  function renderPermissions(host) {
    if (user.role !== "admin") {
      host.innerHTML = panel(
        "Phân quyền",
        `<div class="access-note">
          Chỉ quản trị viên mới có thể thay đổi quyền nhân viên/kế toán.
        </div>`
      );
      return;
    }

    host.innerHTML = panel(
      "Phân quyền nhân viên / kế toán",
      `
      <div class="toolbar">
        <input id="permissionSearch" placeholder="Tìm nhân viên hoặc vai trò">
        <button class="admin-btn" id="permissionExport">Xuất Excel</button>
      </div>

      <div class="cards-2" id="permissionCards">
        ${
          data.staff.map(staff => `
            <div class="mini-card">
              <b>${esc(staff.name)}</b>
              <span>
                ${esc(roleName(staff.role))}
                · ${staff.permissions.length} quyền
              </span>
              <div style="margin-top:8px">
                <button class="admin-btn" data-perm="${staff.id}">
                  Chọn quyền
                </button>
              </div>
            </div>`
          ).join("")
        }
      </div>`
    );

    qsa("[data-perm]", host).forEach(button => {
      button.addEventListener("click", () => {
        permissionModal(button.dataset.perm);
      });
    });

    qs("#permissionSearch", host)?.addEventListener("input", event => {
      const keyword = event.target.value.trim().toLowerCase();

      qsa(".mini-card", qs("#permissionCards", host)).forEach(card => {
        card.hidden = Boolean(keyword && !card.textContent.toLowerCase().includes(keyword));
      });
    });

    qs("#permissionExport", host)?.addEventListener("click", () => {
      const cards = qsa(".mini-card", qs("#permissionCards", host))
        .filter(card => !card.hidden);

      const rows = cards.map(card => {
        const button = card.querySelector("[data-perm]");
        const staff = data.staff.find(item => item.id === button?.dataset.perm);

        return staff
          ? [staff.name, roleName(staff.role), staff.permissions.map(key =>
              PERMISSIONS.find(item => item[0] === key)?.[1] || key
            ).join(", ")]
          : [];
      }).filter(row => row.length);

      exportRowsAsExcel(
        "phan-quyen",
        ["Nhân viên", "Vai trò", "Quyền được cấp"],
        rows
      );
    });
  }
// Reports
  function renderReports(host) {
    const languages = [...new Set(data.courses.map(c => c.language).filter(Boolean))];
    const courseOptions = data.courses.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("");

    host.innerHTML = panel(
      "Biểu đồ & báo cáo",
      `
      <div class="report-toolbar">
        <label>Loại biểu đồ
          <select id="reportChartType">
            <option value="bar">Cột</option>
            <option value="line">Đường</option>
            <option value="area">Miền</option>
            <option value="pie">Tròn</option>
            <option value="donut">Vòng</option>
            <option value="radar">Radar</option>
          </select>
        </label>
        <label>Chỉ số
          <select id="reportMetric">
            <option value="students">Học viên</option>
            <option value="teachers">Giáo viên</option>
            <option value="courses">Khóa học</option>
            <option value="classes">Lớp học</option>
            <option value="enrollments">Đăng ký</option>
            <option value="attendance">Điểm danh</option>
            <option value="results">Kết quả test</option>
            <option value="revenue">Doanh thu</option>
          </select>
        </label>
        <label>Khoảng thời gian
          <select id="reportRange">
            <option value="all">Tất cả</option>
            <option value="7">7 ngày</option>
            <option value="30" selected>30 ngày</option>
            <option value="90">90 ngày</option>
            <option value="365">365 ngày</option>
          </select>
        </label>
        <label>Ngôn ngữ
          <select id="reportLanguage">
            <option value="">Tất cả</option>
            ${languages.map(v => `<option>${esc(v)}</option>`).join("")}
          </select>
        </label>
        <label>Khóa học
          <select id="reportCourse">
            <option value="">Tất cả</option>${courseOptions}
          </select>
        </label>
        <label>Hình thức
          <select id="reportFormat">
            <option value="">Tất cả</option>
            <option>Online</option><option>Offline</option><option>Hybrid</option>
          </select>
        </label>
      </div>

      <div class="report-summary" id="reportSummary"></div>
      <div class="report-chart-wrap" id="reportChart"></div>
      <div class="report-legend" id="reportLegend"></div>`
    );

    ["#reportChartType","#reportMetric","#reportRange","#reportLanguage","#reportCourse","#reportFormat"].forEach(sel => {
      qs(sel, host)?.addEventListener("change", renderChart);
    });

    renderChart();

    function renderChart() {
      const type = qs("#reportChartType", host).value;
      const metric = qs("#reportMetric", host).value;
      const range = qs("#reportRange", host).value;
      const language = qs("#reportLanguage", host).value;
      const courseId = qs("#reportCourse", host).value;
      const format = qs("#reportFormat", host).value;
      const points = buildReportPoints(metric, range, language, courseId, format);
      const total = points.reduce((sum, p) => sum + Number(p.value || 0), 0);
      const max = Math.max(1, ...points.map(p => Number(p.value || 0)));

      qs("#reportSummary", host).innerHTML = [
        [points.length, "Mốc dữ liệu"],
        [total.toLocaleString("vi-VN"), metric === "revenue" ? "Tổng doanh thu" : "Tổng giá trị"],
        [max.toLocaleString("vi-VN"), "Giá trị cao nhất"],
        [typeLabel(type), "Kiểu biểu đồ"]
      ].map(item => `<div class="report"><b>${item[0]}</b><span>${item[1]}</span></div>`).join("");

      qs("#reportChart", host).innerHTML = renderChartMarkup(type, points, max);
      qs("#reportLegend", host).innerHTML = points.map(p => `<span><i></i>${esc(p.label)}: <b>${Number(p.value || 0).toLocaleString("vi-VN")}</b></span>`).join("");
    }

    function typeLabel(type) {
      return ({bar:"Cột",line:"Đường",area:"Miền",pie:"Tròn",donut:"Vòng",radar:"Radar"})[type] || "Cột";
    }
  }

  function buildReportPoints(metric, range, language, courseId, format) {
    const cutoff = range === "all" ? null : Date.now() - Number(range) * 86400000;
    const courses = data.courses.filter(c => c.active !== false && (!language || c.language === language) && (!courseId || c.id === courseId) && (!format || c.format === format));
    const courseIds = new Set(courses.map(c => c.id));
    const labels = ["Học viên","Giáo viên","Khóa học","Lớp học","Đăng ký","Điểm danh","Kết quả test","Doanh thu"];

    if (["students","teachers","courses","classes"].includes(metric)) {
      if (metric === "courses") return courses.map(c => ({label:c.name, value:1}));
      if (metric === "teachers") return data.teachers.map(t => ({label:t.name, value:1}));
      if (metric === "classes") return data.classes.filter(c => courseIds.has(c.courseId)).map(c => ({label:c.name, value:1}));
      return data.students.map(s => ({label:s.name, value:1}));
    }

    const groups = new Map();
    const add = (label, value) => groups.set(label, (groups.get(label) || 0) + value);
    const validDate = value => {
      if (!cutoff) return true;
      const d = new Date(value || 0).getTime();
      return Number.isFinite(d) && d >= cutoff;
    };

    if (metric === "enrollments") {
      data.enrollments.filter(e => courseIds.has(e.courseId) && validDate(e.registeredAt)).forEach(e => add(courseById(e.courseId)?.name || "Khác", 1));
    } else if (metric === "attendance") {
      data.attendance.filter(a => {
        const c = classById(a.classId); return c && courseIds.has(c.courseId) && validDate(a.date);
      }).forEach(a => add(courseById(classById(a.classId)?.courseId)?.name || "Khác", 1));
    } else if (metric === "results") {
      data.testResults.filter(r => validDate(r.createdAt)).forEach(r => add(data.tests.find(t => t.id === r.testId)?.title || "Test", 1));
    } else if (metric === "revenue") {
      data.enrollments.filter(e => courseIds.has(e.courseId) && validDate(e.registeredAt)).forEach(e => add(courseById(e.courseId)?.name || "Khác", courseById(e.courseId)?.price || 0));
    }

    const result = [...groups.entries()].map(([label,value]) => ({label,value}));
    return result.length ? result : courses.slice(0, 6).map(c => ({label:c.name, value:0}));
  }

  function renderChartMarkup(type, points, max) {
    const values = points.map(p => Number(p.value || 0));
    if (!points.length) return `<div class="empty-admin">Không có dữ liệu phù hợp với bộ lọc.</div>`;

    if (type === "pie" || type === "donut") {
      const total = Math.max(1, values.reduce((a,b)=>a+b,0));
      let cursor = 0;
      const stops = points.map((p,i) => {
        const start = cursor / total * 360; cursor += Number(p.value || 0);
        return `hsl(${190 + (i*37)%150} 65% ${45 + (i%3)*8}%) ${start}deg ${cursor/total*360}deg`;
      }).join(",");
      return `<div class="pie-chart ${type === "donut" ? "donut" : ""}" style="background:conic-gradient(${stops})"><div class="pie-hole">${values.reduce((a,b)=>a+b,0).toLocaleString("vi-VN")}</div></div>`;
    }

    if (type === "line" || type === "area") {
      const w=900,h=300,pad=28, step=points.length>1?(w-pad*2)/(points.length-1):w/2;
      const coords=values.map((v,i)=>[pad+i*step,h-pad-(v/max)*(h-pad*2)]);
      const poly=coords.map(c=>c.join(",")).join(" ");
      const area=type === "area" ? `${pad},${h-pad} ${poly} ${pad+(points.length-1)*step},${h-pad}` : "";
      return `<svg class="svg-chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><line x1="${pad}" y1="${h-pad}" x2="${w-pad}" y2="${h-pad}" class="axis"/><polyline points="${poly}" class="${type}-shape" fill="${type === "area" ? "currentColor" : "none"}"/><polyline points="${poly}" class="line-shape"/>${coords.map((c,i)=>`<circle cx="${c[0]}" cy="${c[1]}" r="4"/>`).join("")}</svg>`;
    }

    if (type === "radar") {
      const n=Math.min(values.length,8), cx=50, cy=50, r=38;
      const pts=Array.from({length:n},(_,i)=>{const a=-Math.PI/2+i*2*Math.PI/n; const rr=(values[i]/max)*r; return `${cx+Math.cos(a)*rr},${cy+Math.sin(a)*rr}`;}).join(" ");
      const grid=[1,.75,.5,.25].map(k=>Array.from({length:n},(_,i)=>{const a=-Math.PI/2+i*2*Math.PI/n;return `${cx+Math.cos(a)*r*k},${cy+Math.sin(a)*r*k}`;}).join(" "));
      return `<svg class="radar-chart" viewBox="0 0 100 100">${grid.map(p=>`<polygon points="${p}" class="radar-grid"/>`).join("")}<polygon points="${pts}" class="radar-shape"/></svg>`;
    }

    return `<div class="bar-chart rich-bars">${points.map((p,i)=>`<div class="bar-item"><span class="bar-value">${Number(p.value||0).toLocaleString("vi-VN")}</span><div class="bar" style="height:${Math.max(8,(Number(p.value||0)/max)*220)}px"></div><span class="bar-label">${esc(p.label)}</span></div>`).join("")}</div>`;
  }

  // MODAL
  function openModal(title, html, onReady) {
    modal.innerHTML = `
      <div class="modal-card">
        <h3>${title}</h3>
        ${html}
      </div>`;

    modal.classList.add("open");

    modal.onclick = event => {
      if (event.target === modal) {
        closeModal();
      }
    };

    onReady?.(qs("form", modal));
  }

  function closeModal() {
    modal.classList.remove("open");
    modal.innerHTML = "";
    modal.onclick = null;
  }

  function formButtons() {
    return `
      <div class="form-actions">
        <button type="button" class="admin-btn" data-cancel>Hủy</button>
        <button class="admin-btn primary" type="submit">Lưu</button>
      </div>`;
  }

  function bindCancel(form) {
    qs("[data-cancel]", form?.closest(".modal-card") || modal)
      ?.addEventListener("click", closeModal);
  }

  // COURSE MODAL
  function courseModal(editId = "") {
    const current = data.courses.find(course => course.id === editId) || {
      name: "",
      language: "Tiếng Anh",
      level: "Cơ bản",
      duration: "3 tháng",
      durationGroup: "1-3",
      format: "Offline",
      certificate: true,
      certificateName: "Chứng nhận Yuna",
      price: 0,
      schedule: "",
      image: "../../IMG/course-english.png",
      desc: ""
    };

    openModal(
      editId ? "Sửa khóa học" : "Thêm khóa học",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Tên khóa học
            <input name="name" value="${esc(current.name)}" ${readOnly ? "readonly" : "required"}>
          </label>

          <label>
            Ngôn ngữ
            <input name="language" value="${esc(current.language)}" required>
          </label>

          <label>
            Trình độ
            <input name="level" value="${esc(current.level)}" required>
          </label>

          <label>
            Thời lượng
            <input name="duration" value="${esc(current.duration)}" required>
          </label>

          <label>
            Nhóm thời lượng
            <select name="durationGroup">
              ${durationOptions(current.durationGroup)}
            </select>
          </label>

          <label>
            Hình thức
            <select name="format">
              ${formatOptions(current.format)}
            </select>
          </label>

          <label>
            Học phí
            <input name="price" type="number" min="0" value="${current.price}" required>
          </label>

          <label>
            Chứng chỉ
            <select name="certificate">
              <option value="yes" ${current.certificate ? "selected" : ""}>Có</option>
              <option value="no" ${!current.certificate ? "selected" : ""}>Không</option>
            </select>
          </label>
        </div>

        <label>
          Tên chứng chỉ
          <input name="certificateName" value="${esc(current.certificateName || "")}">
        </label>

        <label>
          Lịch học mẫu
          <input name="schedule" value="${esc(current.schedule || "")}">
        </label>

        <label>
          Đường dẫn ảnh
          <input name="image" value="${esc(current.image || "")}">
        </label>

        <label>
          Mô tả
          <textarea name="desc">${esc(current.desc || "")}</textarea>
        </label>

        ${readOnly ? `<div class="access-note">Phiếu đã xử lý. Chỉ được xem lại, không thể chỉnh sửa.</div>` : formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          if (readOnly) return;

          const fd = new FormData(form);

          const course = {
            id: editId || uid("course-"),
            name: String(fd.get("name")).trim(),
            language: String(fd.get("language")).trim(),
            level: String(fd.get("level")).trim(),
            duration: String(fd.get("duration")).trim(),
            durationGroup: String(fd.get("durationGroup")),
            format: String(fd.get("format")),
            certificate: fd.get("certificate") === "yes",
            certificateName: String(fd.get("certificateName") || "").trim(),
            price: Number(fd.get("price")) || 0,
            schedule: String(fd.get("schedule") || "").trim(),
            image: String(fd.get("image") || "../../IMG/course-english.png").trim(),
            desc: String(fd.get("desc") || "").trim(),
            active: true
          };

          const index = data.courses.findIndex(item => item.id === editId);

          if (index >= 0) {
            data.courses[index] = course;
          } else {
            data.courses.push(course);
          }

          saveData(data);
          addActivity(`${editId ? "Cập nhật" : "Tạo"} khóa học ${course.name}`);
          closeModal();
          renderSection("courses");
        };
      }
    );
  }

  function durationOptions(selected) {
    return [
      ["1-3", "1–3 tháng"],
      ["3-6", "3–6 tháng"],
      ["6-9", "6–9 tháng"],
      ["9+", "Trên 9 tháng"]
    ].map(([value, label]) =>
      `<option value="${value}" ${selected === value ? "selected" : ""}>${label}</option>`
    ).join("");
  }

  function formatOptions(selected) {
    return ["Online", "Offline", "Hybrid"].map(value =>
      `<option ${selected === value ? "selected" : ""}>${value}</option>`
    ).join("");
  }

  // CLASS MODAL
  function classModal(editId = "") {
    const current = data.classes.find(item => item.id === editId) || {
      name: "",
      courseId: data.courses[0]?.id || "",
      teacherId: data.teachers[0]?.id || "",
      room: data.rooms[0]?.name || "",
      format: "Offline",
      schedule: "",
      startDate: today(),
      capacity: 20
    };

    openModal(
      editId ? "Sửa lớp học" : "Thêm lớp học",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Tên lớp
            <input name="name" value="${esc(current.name)}" ${readOnly ? "readonly" : "required"}>
          </label>

          <label>
            Khóa học
            <select name="courseId">
              ${data.courses.map(course =>
                `<option value="${course.id}" ${current.courseId === course.id ? "selected" : ""}>
                  ${esc(course.name)}
                </option>`
              ).join("")}
            </select>
          </label>

          <label>
            Giáo viên
            <select name="teacherId">
              ${data.teachers.map(teacher =>
                `<option value="${teacher.id}" ${current.teacherId === teacher.id ? "selected" : ""}>
                  ${esc(teacher.name)}
                </option>`
              ).join("")}
            </select>
          </label>

          <label>
            Phòng
            <select name="room">
              ${data.rooms.map(room =>
                `<option ${current.room === room.name ? "selected" : ""}>
                  ${esc(room.name)}
                </option>`
              ).join("")}
            </select>
          </label>

          <label>
            Hình thức
            <select name="format">${formatOptions(current.format)}</select>
          </label>

          <label>
            Sức chứa
            <input name="capacity" type="number" min="1" value="${current.capacity}">
          </label>

          <label>
            Khai giảng
            <input name="startDate" type="date" value="${current.startDate}">
          </label>
        </div>

        <label>
          Lịch học
          <input name="schedule" value="${esc(current.schedule || "")}" placeholder="T2 · T4 · T6 | 18:30 - 20:00">
        </label>

        ${readOnly ? `<div class="access-note">Phiếu đã xử lý. Chỉ được xem lại, không thể chỉnh sửa.</div>` : formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          if (readOnly) return;

          const fd = new FormData(form);

          const classItem = {
            id: editId || uid("class-"),
            name: String(fd.get("name")).trim(),
            courseId: String(fd.get("courseId")),
            teacherId: String(fd.get("teacherId")),
            room: String(fd.get("room")),
            format: String(fd.get("format")),
            schedule: String(fd.get("schedule") || "").trim(),
            startDate: String(fd.get("startDate")),
            capacity: Number(fd.get("capacity")) || 1,
            status: "Đang mở"
          };

          const index = data.classes.findIndex(item => item.id === editId);

          if (index >= 0) {
            data.classes[index] = classItem;
          } else {
            data.classes.push(classItem);
          }

          saveData(data);
          addActivity(`${editId ? "Cập nhật" : "Tạo"} lớp ${classItem.name}`);
          closeModal();
          renderSection("classes");
        };
      }
    );
  }

  // ROOM MODAL
  function roomModal(editId = "") {
    const current = data.rooms.find(item => item.id === editId) || {
      name: "",
      capacity: 20,
      location: "Tầng 2",
      equipment: "",
      status: "Trống"
    };

    openModal(
      editId ? "Sửa phòng học" : "Thêm phòng học",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Tên phòng
            <input name="name" value="${esc(current.name)}" ${readOnly ? "readonly" : "required"}>
          </label>

          <label>
            Sức chứa
            <input name="capacity" type="number" min="1" value="${current.capacity}">
          </label>

          <label>
            Vị trí
            <input name="location" value="${esc(current.location || "")}">
          </label>

          <label>
            Trạng thái
            <select name="status">
              ${["Trống","Đang sử dụng","Sẵn sàng"].map(value =>
                `<option ${current.status === value ? "selected" : ""}>${value}</option>`
              ).join("")}
            </select>
          </label>
        </div>

        <label>
          Thiết bị
          <textarea name="equipment">${esc(current.equipment || "")}</textarea>
        </label>

        ${readOnly ? `<div class="access-note">Phiếu đã xử lý. Chỉ được xem lại, không thể chỉnh sửa.</div>` : formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          if (readOnly) return;

          const fd = new FormData(form);

          const room = {
            id: editId || uid("room-"),
            name: String(fd.get("name")).trim(),
            capacity: Number(fd.get("capacity")) || 1,
            location: String(fd.get("location") || "").trim(),
            equipment: String(fd.get("equipment") || "").trim(),
            status: String(fd.get("status"))
          };

          const index = data.rooms.findIndex(item => item.id === editId);

          if (index >= 0) {
            data.rooms[index] = room;
          } else {
            data.rooms.push(room);
          }

          saveData(data);
          closeModal();
          renderSection("rooms");
        };
      }
    );
  }

  // TEACHER MODAL + ACCOUNT
  function teacherModal(editId = "") {
    const current = data.teachers.find(item => item.id === editId) || {
      name: "",
      email: "",
      phone: "",
      specialty: "Tiếng Anh"
    };

    openModal(
      editId ? "Sửa giáo viên" : "Thêm giáo viên",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Họ và tên
            <input name="name" value="${esc(current.name)}" required>
          </label>

          <label>
            Email đăng nhập
            <input name="email" type="email" value="${esc(current.email)}" required>
          </label>

          <label>
            Số điện thoại
            <input name="phone" value="${esc(current.phone || "")}">
          </label>

          <label>
            Chuyên môn
            <input name="specialty" value="${esc(current.specialty || "")}">
          </label>
        </div>

        ${
          editId
            ? `<div class="access-note">Tài khoản giáo viên hiện tại dùng email này. Không cần tạo lại mật khẩu khi chỉnh hồ sơ.</div>`
            : `
              <label>
                Mật khẩu tài khoản
                <input name="password" type="text" value="teacher123" required>
              </label>`
        }

        ${formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          const fd = new FormData(form);
          const email = String(fd.get("email")).trim().toLowerCase();

          const teacher = {
            id: editId || uid("teacher-"),
            name: String(fd.get("name")).trim(),
            email,
            phone: String(fd.get("phone") || "").trim(),
            specialty: String(fd.get("specialty") || "").trim(),
            status: "Đang dạy"
          };

          const index = data.teachers.findIndex(item => item.id === editId);

          if (index >= 0) {
            data.teachers[index] = teacher;
          } else {
            data.teachers.push(teacher);

            const accounts = getAccounts();

            accounts.push({
              email,
              password: String(fd.get("password") || "teacher123"),
              name: teacher.name,
              role: "teacher",
              teacherId: teacher.id
            });

            saveAccounts(accounts);
          }

          saveData(data);
          addActivity(`${editId ? "Cập nhật" : "Tạo"} giáo viên ${teacher.name}`);
          closeModal();
          renderSection("teachers");
        };
      }
    );
  }

  // STUDENT EDIT / ENROLL
  function studentModal(id) {
    const student = studentById(id);

    if (!student) {
      return;
    }

    openModal(
      "Sửa thông tin học viên",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Họ và tên
            <input name="name" value="${esc(student.name)}" required>
          </label>

          <label>
            Email
            <input value="${esc(student.email)}" readonly>
          </label>

          <label>
            Số điện thoại
            <input name="phone" value="${esc(student.phone || "")}">
          </label>

          <label>
            Ngôn ngữ
            <input name="language" value="${esc(student.language || "")}">
          </label>

          <label>
            Mục tiêu
            <input name="goal" value="${esc(student.goal || "")}">
          </label>

          <label>
            Trạng thái
            <select name="status">
              ${["Đang học","Chưa đăng ký khóa học","Tạm nghỉ"].map(value =>
                `<option ${student.status === value ? "selected" : ""}>${value}</option>`
              ).join("")}
            </select>
          </label>
        </div>

        ${formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          const fd = new FormData(form);

          Object.assign(student, {
            name: String(fd.get("name")).trim(),
            phone: String(fd.get("phone") || "").trim(),
            language: String(fd.get("language") || "").trim(),
            goal: String(fd.get("goal") || "").trim(),
            status: String(fd.get("status"))
          });

          saveData(data);
          closeModal();
          renderSection("students");
        };
      }
    );
  }

  function enrollModal(studentId) {
    const student = studentById(studentId);

    if (!student) {
      return;
    }

    openModal(
      `Đăng ký khóa cho ${student.name}`,
      `
      <form class="admin-form">
        <label>
          Khóa học
          <select name="courseId">
            ${data.courses.map(course =>
              `<option value="${course.id}">
                ${esc(course.name)}
              </option>`
            ).join("")}
          </select>
        </label>

        <label>
          Lớp
          <select name="classId" id="adminEnrollClass">
            <option value="">Tự chọn lớp phù hợp</option>
            ${data.classes.map(classItem =>
              `<option value="${classItem.id}">
                ${esc(classItem.name)} · ${esc(courseById(classItem.courseId)?.name || "")}
              </option>`
            ).join("")}
          </select>
        </label>

        ${formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        const courseSelect = qs('[name="courseId"]', form);
        const classSelect = qs("#adminEnrollClass", form);

        function filterClasses() {
          const courseId = courseSelect.value;

          classSelect.innerHTML = `
            <option value="">Tự chọn lớp phù hợp</option>
            ${data.classes
              .filter(item => item.courseId === courseId)
              .map(item =>
                `<option value="${item.id}">
                  ${esc(item.name)} · ${esc(item.room)}
                </option>`
              ).join("")}`;
        }

        courseSelect.addEventListener("change", filterClasses);
        filterClasses();

        form.onsubmit = event => {
          event.preventDefault();

          const fd = new FormData(form);
          const courseId = String(fd.get("courseId"));
          const classId = String(
            fd.get("classId") ||
            data.classes.find(item => item.courseId === courseId)?.id ||
            ""
          );

          const exists = data.enrollments.some(enrollment =>
            enrollment.studentId === studentId &&
            enrollment.courseId === courseId &&
            enrollment.status !== "cancelled"
          );

          if (exists) {
            alert("Học viên đã có khóa học này.");
            return;
          }

          data.enrollments.push({
            id: uid("enr-"),
            studentId,
            courseId,
            classId,
            status: "approved",
            registeredAt: today(),
            progress: 0
          });

          student.status = "Đang học";

          saveData(data);
          addActivity(
            `Admin đăng ký ${student.name} vào ${courseById(courseId)?.name || "khóa học"}`
          );

          closeModal();
          renderSection("students");
        };
      }
    );
  }

  // TEST MODAL
  function testModal(editId = "") {
    const current = data.tests.find(test => test.id === editId) || {
      title: "",
      language: "Tiếng Anh",
      level: "Cơ bản",
      durationMinutes: 15,
      questions: []
    };

    const questionText = current.questions.map((question, index) => {
      return [
        `Câu ${index + 1}. ${question.q}`,
        `A. ${question.answers[0] || ""}`,
        `B. ${question.answers[1] || ""}`,
        `C. ${question.answers[2] || ""}`,
        `D. ${question.answers[3] || ""}`,
        `Đáp án: ${["A","B","C","D"][question.correct] || "A"}`
      ].join("\n");
    }).join("\n\n");

    openModal(
      editId ? "Sửa bài test" : "Tạo bài test",
      `
      <form class="admin-form test-form">
        <div class="form-grid">
          <label>
            Tên bài test
            <input name="title" value="${esc(current.title)}" required>
          </label>

          <label>
            Thời lượng (phút)
            <input name="durationMinutes" type="number" min="1" value="${current.durationMinutes}">
          </label>

          <label>
            Ngôn ngữ
            <select name="language">
              ${["Tiếng Anh","Tiếng Hàn","Tiếng Trung","Tiếng Nhật"].map(v => `<option ${current.language === v ? "selected" : ""}>${v}</option>`).join("")}
            </select>
          </label>

          <label>
            Trình độ
            <select name="level">
              ${["Cơ bản","Trung cấp","Nâng cao"].map(v => `<option ${current.level === v ? "selected" : ""}>${v}</option>`).join("")}
            </select>
          </label>
        </div>

        <div class="word-import-box">
          <div>
            <b>Nhập danh sách câu hỏi từ Word</b>
            <span>Hỗ trợ .docx. Hệ thống sẽ đọc Câu 1, A/B/C/D và dòng Đáp án.</span>
          </div>
          <label class="file-btn">
            Chọn file Word
            <input id="questionWordFile" type="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
          </label>
        </div>

        <label>
          Ngân hàng câu hỏi
          <textarea name="questionsText" id="questionsText" class="question-bank" placeholder="Câu 1. ...\nA. ...\nB. ...\nC. ...\nD. ...\nĐáp án: A">${esc(questionText)}</textarea>
        </label>

        <div class="access-note">
          Mỗi câu có thể viết theo dạng <b>Câu 1.</b> hoặc <b>1.</b>, tiếp theo là A/B/C/D và <b>Đáp án: A</b>. Có thể nhập hàng loạt bằng file Word.
        </div>

        ${formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        const fileInput = qs("#questionWordFile", form);
        fileInput?.addEventListener("change", async event => {
          const file = event.target.files?.[0];
          if (!file) return;
          try {
            const questions = await parseWordQuestions(file);
            if (!questions.length) {
              alert("Không tìm thấy câu hỏi hợp lệ trong file Word. Hãy dùng mẫu Câu/A/B/C/D/Đáp án.");
              return;
            }
            qs("#questionsText", form).value = questions.map((q, i) => [
              `Câu ${i + 1}. ${q.q}`,
              `A. ${q.answers[0]}`,
              `B. ${q.answers[1]}`,
              `C. ${q.answers[2]}`,
              `D. ${q.answers[3]}`,
              `Đáp án: ${["A","B","C","D"][q.correct]}`
            ].join("\n")).join("\n\n");
            const title = String(qs('[name="title"]', form)?.value || "").trim();
            if (!title) qs('[name="title"]', form).value = file.name.replace(/\.docx$/i, "");
          } catch (error) {
            console.error(error);
            alert("Không đọc được file Word. Hãy kiểm tra file .docx và thử lại.");
          }
        });

        form.onsubmit = event => {
          event.preventDefault();

          const fd = new FormData(form);
          const test = {
            id: editId || uid("test-"),
            title: String(fd.get("title") || "").trim(),
            durationMinutes: Number(fd.get("durationMinutes")) || 15,
            language: String(fd.get("language") || "Tiếng Anh").trim(),
            level: String(fd.get("level") || "Cơ bản").trim(),
            questions: parseQuestions(String(fd.get("questionsText") || ""))
          };

          if (!test.questions.length) {
            alert("Bài test cần ít nhất 1 câu hỏi hợp lệ.");
            return;
          }

          const index = data.tests.findIndex(item => item.id === editId);
          if (index >= 0) data.tests[index] = test;
          else data.tests.push(test);

          saveData(data);
          addActivity(`${editId ? "Cập nhật" : "Tạo"} bài test ${test.title}`);
          closeModal();
          renderSection("tests");
        };
      }
    );
  }

  async function parseWordQuestions(file) {
    if (!window.JSZip) throw new Error("Thiếu thư viện đọc Word");
    const zip = await JSZip.loadAsync(file);
    const xml = await zip.file("word/document.xml")?.async("text");
    if (!xml) throw new Error("Không có word/document.xml");

    const doc = new DOMParser().parseFromString(xml, "application/xml");
    const paragraphs = [...doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "p")]
      .map(p => [...p.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "t")].map(t => t.textContent).join("").replace(/\s+/g, " ").trim())
      .filter(Boolean);

    return parseQuestions(paragraphs.join("\n"));
  }

  function parseQuestions(text) {
    const lines = text
      .replace(/\r/g, "")
      .split("\n")
      .map(line => line.trim())
      .filter(Boolean);

    const questions = [];
    let current = null;

    const push = () => {
      if (!current) return;
      const clean = {
        q: current.q.trim(),
        answers: [current.answers[0] || "", current.answers[1] || "", current.answers[2] || "", current.answers[3] || ""],
        correct: Math.max(0, ["A","B","C","D"].indexOf(current.correct || "A"))
      };
      if (clean.q && clean.answers.some(Boolean)) questions.push(clean);
      current = null;
    };

    lines.forEach(line => {
      const qMatch = line.match(/^(?:câu\s*)?(\d+)\s*[\.:\-]\s*(.+)$/i);
      const aMatch = line.match(/^([A-D])\s*[\.)\:\-]\s*(.+)$/i);
      const ansMatch = line.match(/^(?:đáp\s*án|answer|correct)\s*[:\-]\s*([A-D])/i);

      if (qMatch) {
        push();
        current = { q: qMatch[2], answers: [], correct: "A" };
        return;
      }
      if (!current) return;
      if (aMatch) {
        current.answers["ABCD".indexOf(aMatch[1].toUpperCase())] = aMatch[2];
        return;
      }
      if (ansMatch) {
        current.correct = ansMatch[1].toUpperCase();
        return;
      }
      current.q += ` ${line}`;
    });

    push();
    return questions;
  }

  // TICKET MODAL
  function ticketModal(type, editId = "", readOnly = false) {
    const current = data.tickets.find(ticket => ticket.id === editId) || {
      name: "",
      contact: "",
      subject: "",
      message: "",
      status: "Mới"
    };

    openModal(
      readOnly
        ? "Xem phiếu đã xử lý"
        : type === "care"
          ? "Phiếu chăm sóc khách hàng"
          : "Xử lý khiếu nại",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Khách hàng
            <input name="name" value="${esc(current.name)}" ${readOnly ? "readonly" : "required"}>
          </label>

          <label>
            Liên hệ
            <input name="contact" value="${esc(current.contact || "")}" ${readOnly ? "readonly" : ""}>
          </label>
        </div>

        <label>
          Chủ đề
          <input name="subject" value="${esc(current.subject || "")}" ${readOnly ? "readonly" : ""}>
        </label>

        <label>
          Nội dung
          <textarea name="message" ${readOnly ? "readonly" : ""}>${esc(current.message || "")}</textarea>
        </label>

        <label>
          Trạng thái
          <select name="status" ${readOnly ? "disabled" : ""}>
            ${["Mới","Đang xử lý","Đã liên hệ","Hoàn tất","Từ chối"].map(value =>
              `<option ${current.status === value ? "selected" : ""}>${value}</option>`
            ).join("")}
          </select>
        </label>

        ${readOnly ? `<div class="access-note">Phiếu đã xử lý. Chỉ được xem lại, không thể chỉnh sửa.</div>` : formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          if (readOnly) return;

          const fd = new FormData(form);

          const ticket = {
            id: editId || uid("ticket-"),
            type,
            name: String(fd.get("name")).trim(),
            contact: String(fd.get("contact") || "").trim(),
            subject: String(fd.get("subject") || "").trim(),
            message: String(fd.get("message") || "").trim(),
            status: String(fd.get("status")),
            createdAt: current.createdAt || today()
          };

          const index = data.tickets.findIndex(item => item.id === editId);

          if (index >= 0) {
            data.tickets[index] = ticket;
          } else {
            data.tickets.unshift(ticket);
          }

          saveData(data);
          addActivity(`Cập nhật phiếu ${type === "care" ? "chăm sóc" : "khiếu nại"}`);
          closeModal();
          renderSection(type);
        };
      }
    );
  }

  // STAFF MODAL
  function staffModal(editId = "") {
    const current = data.staff.find(item => item.id === editId) || {
      name: "",
      email: "",
      phone: "",
      role: "staff",
      permissions: ["dashboard"]
    };

    openModal(
      editId ? "Sửa nhân viên" : "Thêm nhân viên",
      `
      <form class="admin-form">
        <div class="form-grid">
          <label>
            Họ và tên
            <input name="name" value="${esc(current.name)}" required>
          </label>

          <label>
            Email
            <input name="email" type="email" value="${esc(current.email)}" required>
          </label>

          <label>
            Số điện thoại
            <input name="phone" value="${esc(current.phone || "")}">
          </label>

          <label>
            Loại tài khoản
            <select name="role">
              <option value="staff" ${current.role === "staff" ? "selected" : ""}>Nhân viên</option>
              <option value="accountant" ${current.role === "accountant" ? "selected" : ""}>Kế toán</option>
            </select>
          </label>

          <label>
            Lương cơ bản
            <input name="baseSalary" type="number" min="0" value="${Number(current.baseSalary) || 8000000}">
          </label>

          <label>
            Phụ cấp mặc định
            <input name="allowance" type="number" min="0" value="${Number(current.allowance) || 0}">
          </label>

          <label>
            Khấu trừ mặc định
            <input name="deduction" type="number" min="0" value="${Number(current.deduction) || 0}">
          </label>
        </div>

        ${
          editId
            ? `<div class="access-note">Chỉnh sửa hồ sơ không tự đổi mật khẩu.</div>`
            : `<label>Mật khẩu<input name="password" value="staff123" required></label>`
        }

        ${formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          const fd = new FormData(form);
          const email = String(fd.get("email")).trim().toLowerCase();

          const staff = {
            id: editId || uid("staff-"),
            name: String(fd.get("name")).trim(),
            email,
            phone: String(fd.get("phone") || "").trim(),
            role: String(fd.get("role")),
            status: "Đang làm",
            baseSalary: Number(fd.get("baseSalary")) || 0,
            allowance: Number(fd.get("allowance")) || 0,
            deduction: Number(fd.get("deduction")) || 0,
            permissions: current.permissions || ["dashboard"]
          };

          const index = data.staff.findIndex(item => item.id === editId);

          if (index >= 0) {
            data.staff[index] = staff;
          } else {
            data.staff.push(staff);

            const accounts = getAccounts();

            if (!accounts.some(account => account.email === email)) {
              accounts.push({
                email,
                password: String(fd.get("password") || "staff123"),
                name: staff.name,
                role: staff.role,
                staffId: staff.id
              });

              saveAccounts(accounts);
            }
          }

          saveData(data);
          addActivity(`${editId ? "Cập nhật" : "Tạo"} tài khoản ${staff.name}`);
          closeModal();
          renderSection("staff");
          renderSection("permissions");
        };
      }
    );
  }

  // PERMISSION MODAL
  function permissionModal(staffId) {
    if (user.role !== "admin") {
      return;
    }

    const staff = data.staff.find(item => item.id === staffId);

    if (!staff) {
      return;
    }

    openModal(
      `Phân quyền · ${staff.name}`,
      `
      <form class="admin-form">
        <div class="permission-grid">
          ${
            PERMISSIONS
              .filter(([key]) => !["accounts", "permissions", "loginHistory"].includes(key))
              .map(([key, label]) => `
              <label class="permission-item">
                <input
                  type="checkbox"
                  name="permission"
                  value="${key}"
                  ${staff.permissions.includes(key) ? "checked" : ""}
                >
                ${label}
              </label>`
            ).join("")
          }
        </div>

        ${formButtons()}
      </form>`,
      form => {
        bindCancel(form);

        form.onsubmit = event => {
          event.preventDefault();

          staff.permissions = [
            ...form.querySelectorAll(
              'input[name="permission"]:checked'
            )
          ].map(input => input.value);

          saveData(data);

          if (staff.id === currentUser()?.staffId) {
            setUser({
              ...currentUser(),
              ...staff
            });
          }

          closeModal();
          renderSection("permissions");
        };
      }
    );
  }
});
