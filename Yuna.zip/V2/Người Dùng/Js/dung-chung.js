const MK = {
  data: "mermaid_data_v7",
  accounts: "mermaid_accounts_v7",
  user: "mermaid_user_v7",
  login: "mermaid_login_v7",
  pending: "mermaid_pending_course_v7",
  pendingTest: "mermaid_pending_test_v1"
};

const ROLE_NAME = {
  admin: "Quản trị viên",
  staff: "Nhân viên",
  accountant: "Kế toán",
  teacher: "Giáo viên",
  student: "Học viên"
};

const PERMISSIONS = [
  ["dashboard", "Tổng quan"],
  ["students", "Học viên"],
  ["teachers", "Giáo viên"],
  ["courses", "Khóa học"],
  ["classes", "Lớp học"],
  ["rooms", "Phòng học"],
  ["attendance", "Điểm danh"],
  ["leave", "Đơn nghỉ"],
  ["tests", "Tạo test"],
  ["results", "Kết quả test"],
  ["care", "Chăm sóc KH"],
  ["complaints", "Khiếu nại"],
  ["staff", "Quản lý NV"],
  ["accounts", "Tài khoản"],
  ["permissions", "Phân quyền"],
  ["reports", "Biểu đồ & báo cáo"]
];

function qs(selector, parent = document) {
  return parent.querySelector(selector);
}

function qsa(selector, parent = document) {
  return [...parent.querySelectorAll(selector)];
}

function uid(prefix = "id") {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function money(value) {
  return new Intl.NumberFormat("vi-VN").format(Number(value) || 0) + "đ";
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function fmtDate(value) {
  if (!value) return "—";

  const date = new Date(value + "T00:00:00");
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("vi-VN");
}

function esc(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function roleName(role) {
  return ROLE_NAME[role] || role;
}

function seedData() {
  return {
    courses: [
      {
        id: "c-eng",
        name: "Tiếng Anh Giao Tiếp",
        language: "Tiếng Anh",
        level: "Cơ bản",
        duration: "3 tháng",
        durationGroup: "1-3",
        format: "Offline",
        certificate: true,
        certificateName: "Chứng nhận Yuna",
        price: 3200000,
        schedule: "T2 · T4 · T6 | 18:30 - 20:00",
        image: "../../IMG/course-english.png",
        desc: "Phát âm, phản xạ và giao tiếp thực tế.",
        active: true
      },
      {
        id: "c-kor",
        name: "Tiếng Hàn Sơ cấp",
        language: "Tiếng Hàn",
        level: "Cơ bản",
        duration: "4 tháng",
        durationGroup: "3-6",
        format: "Online",
        certificate: true,
        certificateName: "Chứng nhận hoàn thành",
        price: 4200000,
        schedule: "T3 · T5 | 19:00 - 20:30",
        image: "../../IMG/course-korean.png",
        desc: "Học bảng chữ cái, phát âm và hội thoại.",
        active: true
      },
      {
        id: "c-chn",
        name: "Tiếng Trung Chuyên sâu",
        language: "Tiếng Trung",
        level: "Trung cấp",
        duration: "5 tháng",
        durationGroup: "3-6",
        format: "Offline",
        certificate: true,
        certificateName: "Lộ trình HSK",
        price: 4800000,
        schedule: "T2 · T4 · T6 | 19:00 - 20:30",
        image: "../../IMG/course-chinese.png",
        desc: "Nghe, nói, đọc, viết và luyện HSK.",
        active: true
      },
      {
        id: "c-jpn",
        name: "Tiếng Nhật N5–N4",
        language: "Tiếng Nhật",
        level: "Cơ bản",
        duration: "5 tháng",
        durationGroup: "3-6",
        format: "Offline",
        certificate: true,
        certificateName: "Luyện thi JLPT",
        price: 3500000,
        schedule: "T3 · T5 · T7 | 18:30 - 20:00",
        image: "../../IMG/course-japanese.png",
        desc: "Kana, ngữ pháp, hội thoại và JLPT.",
        active: true
      },
      {
        id: "c-eng2",
        name: "Tiếng Anh Công Sở",
        language: "Tiếng Anh",
        level: "Trung cấp",
        duration: "6 tháng",
        durationGroup: "3-6",
        format: "Online",
        certificate: true,
        certificateName: "Chứng nhận Yuna",
        price: 5600000,
        schedule: "T2 · T4 | 20:00 - 21:30",
        image: "../../IMG/course-english.png",
        desc: "Email, họp, thuyết trình và giao tiếp công sở.",
        active: true
      },
      {
        id: "c-topik",
        name: "Luyện TOPIK II",
        language: "Tiếng Hàn",
        level: "Nâng cao",
        duration: "8 tháng",
        durationGroup: "6-9",
        format: "Hybrid",
        certificate: false,
        certificateName: "",
        price: 6500000,
        schedule: "T7 · CN | 08:30 - 10:00",
        image: "../../IMG/course-korean.png",
        desc: "Luyện đọc, viết, từ vựng và chiến lược TOPIK.",
        active: true
      }
    ],

    teachers: [
      {
        id: "t-1",
        name: "Nguyễn Minh Anh",
        email: "teacher@mermaid.vn",
        phone: "0901000111",
        specialty: "Tiếng Anh"
      },
      {
        id: "t-2",
        name: "Trần Hà My",
        email: "teacher2@mermaid.vn",
        phone: "0901000222",
        specialty: "Tiếng Hàn"
      }
    ],

    students: [],

    classes: [
      {
        id: "cl-1",
        name: "ENG-GT01",
        courseId: "c-eng",
        teacherId: "t-1",
        room: "P.201",
        format: "Offline",
        schedule: "T2 · T4 · T6 | 18:30 - 20:00",
        startDate: "2026-10-01",
        capacity: 20,
        status: "Đang mở"
      },
      {
        id: "cl-2",
        name: "KOR-01",
        courseId: "c-kor",
        teacherId: "t-2",
        room: "Online Zoom",
        format: "Online",
        schedule: "T3 · T5 | 19:00 - 20:30",
        startDate: "2026-10-05",
        capacity: 25,
        status: "Đang mở"
      },
      {
        id: "cl-3",
        name: "JPN-N5-01",
        courseId: "c-jpn",
        teacherId: "t-1",
        room: "P.202",
        format: "Offline",
        schedule: "T3 · T5 · T7 | 18:30 - 20:00",
        startDate: "2026-10-08",
        capacity: 18,
        status: "Đang mở"
      }
    ],

    rooms: [
      {
        id: "r-1",
        name: "P.201",
        capacity: 20,
        location: "Tầng 2",
        equipment: "TV · Loa · Điều hòa",
        status: "Đang sử dụng"
      },
      {
        id: "r-2",
        name: "P.202",
        capacity: 25,
        location: "Tầng 2",
        equipment: "Máy chiếu · Loa",
        status: "Trống"
      },
      {
        id: "r-3",
        name: "Online Zoom",
        capacity: 100,
        location: "Trực tuyến",
        equipment: "Zoom · Drive",
        status: "Sẵn sàng"
      }
    ],

    enrollments: [],
    attendance: [],
    leaveRequests: [],

    tests: [
      {
        id: "test-1",
        title: "Kiểm tra đầu vào Tiếng Anh A1",
        language: "Tiếng Anh",
        level: "Cơ bản",
        durationMinutes: 15,
        questions: [
          {
            q: "She ___ to school every day.",
            answers: ["go", "goes", "going", "gone"],
            correct: 1
          },
          {
            q: "Hello nghĩa là gì?",
            answers: ["Xin chào", "Tạm biệt", "Cảm ơn", "Xin lỗi"],
            correct: 0
          },
          {
            q: "I ___ a student.",
            answers: ["am", "is", "are", "be"],
            correct: 0
          }
        ]
      }
    ],

    testResults: [],

    tickets: [
      {
        id: "tk-1",
        type: "care",
        name: "Khách hàng mẫu",
        contact: "0909000000",
        subject: "Tư vấn khóa Hàn",
        message: "Cho em lịch khai giảng tháng tới.",
        status: "Mới",
        createdAt: "2026-09-18"
      },
      {
        id: "tk-2",
        type: "complaint",
        name: "Học viên mẫu",
        contact: "0909111222",
        subject: "Xin đổi lịch",
        message: "Em cần đổi lịch vì trùng lịch làm việc.",
        status: "Đang xử lý",
        createdAt: "2026-09-17"
      }
    ],

    staff: [
      {
        id: "st-1",
        name: "Lê Quốc Bảo",
        email: "staff@mermaid.vn",
        phone: "0902000111",
        role: "staff",
        status: "Đang làm",
        permissions: [
          "dashboard",
          "students",
          "teachers",
          "courses",
          "classes",
          "rooms",
          "attendance",
          "leave",
          "care",
          "complaints",
          "reports"
        ]
      },
      {
        id: "st-2",
        name: "Phạm Thu Hà",
        email: "accountant@mermaid.vn",
        phone: "0902000222",
        role: "accountant",
        status: "Đang làm",
        permissions: ["dashboard", "courses", "results", "reports"]
      }
    ],

    notifications: [
      {
        id: "n-1",
        title: "Chào mừng đến Yuna",
        content: "Đăng ký khóa học để kích hoạt lịch học, thông báo và theo dõi tiến độ.",
        audience: "all",
        createdAt: "2026-09-18"
      }
    ],

    activity: ["Khởi tạo hệ thống Yuna Language Center"]
  };
}

function getData() {
  try {
    const raw = localStorage.getItem(MK.data);

    if (!raw) {
      const data = seedData();
      saveData(data);
      return data;
    }

    return JSON.parse(raw);
  } catch (error) {
    const data = seedData();
    saveData(data);
    return data;
  }
}

function saveData(data) {
  localStorage.setItem(MK.data, JSON.stringify(data));
}

function getAccounts() {
  try {
    return JSON.parse(localStorage.getItem(MK.accounts) || "[]");
  } catch (error) {
    return [];
  }
}

function saveAccounts(accounts) {
  localStorage.setItem(MK.accounts, JSON.stringify(accounts));
}

function seedAccounts() {
  const accounts = getAccounts();
  const demos = [
    {
      email: "admin@gmail.com",
      password: "Mduyen952004",
      name: "Vũ Thị Mỹ Duyên",
      role: "admin"
    },
    {
      email: "admin@mermaid.vn",
      password: "admin123",
      name: "Quản trị viên",
      role: "admin"
    },
    {
      email: "staff@mermaid.vn",
      password: "staff123",
      name: "Lê Quốc Bảo",
      role: "staff",
      staffId: "st-1"
    },
    {
      email: "accountant@mermaid.vn",
      password: "account123",
      name: "Phạm Thu Hà",
      role: "accountant",
      staffId: "st-2"
    },
    {
      email: "teacher@mermaid.vn",
      password: "teacher123",
      name: "Nguyễn Minh Anh",
      role: "teacher",
      teacherId: "t-1"
    }
  ];

  demos.forEach(account => {
    const index = accounts.findIndex(item => item.email.toLowerCase() === account.email.toLowerCase());

    if (index === -1) {
      accounts.push(account);
      return;
    }

    // Keep demo accounts synchronized with the current project defaults.
    accounts[index] = { ...accounts[index], ...account };
  });

  saveAccounts(accounts);
}

function currentUser() {
  try {
    return JSON.parse(localStorage.getItem(MK.user) || "null");
  } catch (error) {
    return null;
  }
}

function setUser(user) {
  localStorage.setItem(MK.user, JSON.stringify(user));
  localStorage.setItem(MK.login, "1");
}

function clearUser() {
  localStorage.removeItem(MK.user);
  localStorage.removeItem(MK.login);
}

function isLogged() {
  return Boolean(currentUser()) && localStorage.getItem(MK.login) === "1";
}

function courseById(id) {
  return getData().courses.find(item => item.id === id) || null;
}

function classById(id) {
  return getData().classes.find(item => item.id === id) || null;
}

function teacherById(id) {
  return getData().teachers.find(item => item.id === id) || null;
}

function studentById(id) {
  return getData().students.find(item => item.id === id) || null;
}

function myEnrollments(studentId) {
  return getData().enrollments.filter(
    item => item.studentId === studentId && item.status !== "cancelled"
  );
}

function hasEnrollment(studentId) {
  return myEnrollments(studentId).length > 0;
}

function goToLoginForTest() {
  localStorage.setItem(MK.pendingTest, "1");
  location.href = "index.html#account";
}

function studentHasNotification(studentId, notice) {
  return (
    notice.audience === "all" ||
    (notice.audience === "student" && !notice.targetId) ||
    (notice.audience === "student" && notice.targetId === studentId)
  );
}

function addActivity(text) {
  const data = getData();
  data.activity.unshift(text);
  data.activity = data.activity.slice(0, 60);
  saveData(data);
}

function addNotice(title, content, audience = "all", targetId = "") {
  const data = getData();
  data.notifications.unshift({
    id: uid("n-"),
    title,
    content,
    audience,
    targetId,
    createdAt: today()
  });
  saveData(data);
}

function buildHeader() {
  const host = qs("#header");

  if (!host) return;

  const page = location.pathname.split("/").pop() || "index.html";
  const user = currentUser();

  let accountButton = `
    <button class="header-account" type="button" data-open-account="login">
      👤 Đăng nhập / Đăng ký
    </button>`;

  if (user) {
    const links = [
      `<a href="thong-tin-hoc-vien.html">👤 Thông tin cá nhân</a>`
    ];

    if (user.role === "student" && hasEnrollment(user.studentId)) {
      links.push(
        `<a href="khoa-hoc-cua-toi.html">📚 Khóa học của tôi</a>`,
        `<a href="lich-hoc.html">📅 Theo dõi lịch học</a>`,
        `<a href="thong-bao.html">🔔 Thông báo</a>`,
        `<a href="xin-nghi.html">📝 Xin nghỉ / Đơn mẫu</a>`
      );
    }

    if (user.role === "teacher") {
      links.push(
        `<a href="giao-vien.html">🧑‍🏫 Trang giáo viên</a>`,
        `<a href="lich-day.html">📅 Lịch dạy</a>`,
        `<a href="diem-danh.html">✅ Điểm danh</a>`,
        `<a href="theo-doi-hoc-sinh.html">📈 Theo dõi học sinh</a>`,
        `<a href="xin-nghi.html">📝 Xin nghỉ / Đơn mẫu</a>`
      );
    }

    if (["admin", "staff", "accountant"].includes(user.role)) {
      links.push(`<a href="../../Quan Tri/quan-tri.html">⚙ Khu vực quản trị</a>`);
    }

    accountButton = `
      <div class="account-user-wrap">
        <button class="header-user-button" id="headerUserButton" type="button">
          <span class="user-avatar">${esc((user.name || "M")[0].toUpperCase())}</span>
          <span class="user-name">${esc(user.name)}</span>
          <span>⌄</span>
        </button>

        <button class="header-logout" id="headerLogout" type="button">
          Đăng xuất
        </button>

        <div class="user-dropdown" id="userDropdown">
          <div class="user-dropdown-head">
            <strong>${esc(user.name)}</strong>
            <small>${esc(roleName(user.role))}</small>
          </div>
          ${links.join("")}
          <button class="user-dropdown-logout" id="dropdownLogout" type="button">
            Đăng xuất
          </button>
        </div>
      </div>`;
  }

  const active = file => page === file ? "active" : "";

  host.innerHTML = `
    <header class="site-header">
      <div class="header-inner">
        <a class="brand" href="index.html">
          <span class="brand-avatar">
            <img src="../../IMG/logo-merimaid.jpg" alt="Yuna Language Center">
          </span>
          <span class="brand-name">
            <strong>YUNA</strong>
            <small>LANGUAGE CENTER</small>
          </span>
        </a>

        <nav class="main-nav" id="mainNav">
          <a class="${active("index.html")}" href="index.html">Trang chủ</a>
          <a class="${active("khoa-hoc.html")}" href="khoa-hoc.html">Khóa học</a>
          <a class="${active("gioi-thieu.html")}" href="gioi-thieu.html">Giới thiệu</a>
          <a class="${active("bai-test.html")}" href="bai-test.html">Bài test</a>
          <a class="${active("lien-he.html")}" href="lien-he.html">Liên hệ</a>
        </nav>

        <div class="header-right">
          ${accountButton}
        </div>

        <button class="menu-btn" id="menuBtn" type="button">☰</button>
      </div>
    </header>`;

  qs("#menuBtn")?.addEventListener("click", () => {
    qs("#mainNav")?.classList.toggle("open");
  });

  qs("#headerUserButton")?.addEventListener("click", event => {
    event.stopPropagation();
    qs("#userDropdown")?.classList.toggle("open");
  });

  qs("#headerLogout")?.addEventListener("click", () => {
    window.AccountUI?.logout();
  });

  qs("#dropdownLogout")?.addEventListener("click", () => {
    window.AccountUI?.logout();
  });

  if (!window.__mermaidHeaderClickBound) {
    document.addEventListener("click", event => {
      if (!event.target.closest(".account-user-wrap")) {
        qs("#userDropdown")?.classList.remove("open");
      }
    });

    window.__mermaidHeaderClickBound = true;
  }
}

function buildFooter() {
  const footer = qs("#footer");

  if (!footer) return;

  footer.innerHTML = `
    <footer class="site-footer">
      <div class="footer-inner">
        <div>
          <h3>YUNA</h3>
          <p>
            Trung tâm ngoại ngữ phong cách đại dương, đồng hành cùng bạn trên hành trình chinh phục ngôn ngữ.
          </p>
        </div>

        <div>
          <h3>Khám phá</h3>
          <a href="khoa-hoc.html">Khóa học</a>
          <a href="bai-test.html">Bài test</a>
          <a href="gioi-thieu.html">Giới thiệu</a>
        </div>

        <div>
          <h3>Liên hệ</h3>
          <p>0900 123 456<br>hello@mermaid.vn</p>
          <a href="lien-he.html">Gửi yêu cầu tư vấn →</a>
        </div>
      </div>

      <div class="footer-bottom">© 2026 Yuna Language Center</div>
    </footer>`;
}

document.addEventListener("DOMContentLoaded", () => {
  seedAccounts();
  getData();
  buildHeader();
  buildFooter();
});
