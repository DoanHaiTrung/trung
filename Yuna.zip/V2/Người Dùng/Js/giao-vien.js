
document.addEventListener("DOMContentLoaded", () => {
  const user = currentUser();
  if (!user || user.role !== "teacher") {
    location.href = "index.html";
    return;
  }

  const data = getData();
  const classes = data.classes.filter(c => c.teacherId === user.teacherId);
  const students = data.enrollments.filter(e =>
    classes.some(c => c.id === e.classId) && e.status !== "cancelled"
  );

  qs("#teacherClassCount") && (qs("#teacherClassCount").textContent = classes.length);
  qs("#teacherStudentCount") && (qs("#teacherStudentCount").textContent = students.length);
  qs("#teacherAttendanceCount") && (
    qs("#teacherAttendanceCount").textContent =
    data.attendance.filter(a => classes.some(c => c.id === a.classId)).length
  );

  qs("#teacherClasses").innerHTML = classes.length
    ? classes.map(c => {
        const course = courseById(c.courseId);
        const count = data.enrollments.filter(e => e.classId === c.id && e.status !== "cancelled").length;

        return `
          <article class="teacher-class">
            <span>${esc(c.format)}</span>
            <h3>${esc(c.name)}</h3>
            <p>${esc(course?.name || "")}</p>
            <strong>${count}/${c.capacity} học viên</strong>
            <small>${esc(c.schedule)} · ${esc(c.room)}</small>
          </article>`;
      }).join("")
    : `<div class="notice-inline">Chưa được phân công lớp.</div>`;
});
