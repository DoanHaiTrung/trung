document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#testArea");
  if (!root) return;

  const tests = getData().tests;
  if (!tests.length) {
    root.innerHTML = `<div class="notice-inline">Chưa có bài test.</div>`;
    return;
  }

  const user = currentUser();
  const shouldStart = new URLSearchParams(location.search).get("start") === "1";

  if (!user) {
    renderLoginGate();
    return;
  }

  renderTestSetup(false);

  function renderLoginGate() {
    root.innerHTML = `
      <div class="test-gate">
        <div class="test-gate-icon">🔐</div>
        <span class="eyebrow">YÊU CẦU ĐĂNG NHẬP</span>
        <h2>Đăng nhập để làm bài test</h2>
        <p>Bạn vẫn có thể xem trang bài test. Khi bấm <strong>Bắt đầu làm bài</strong>, hệ thống sẽ đưa bạn về trang chủ để đăng nhập.</p>
        <button class="btn primary" id="testLoginBtn" type="button">Bắt đầu làm bài →</button>
      </div>`;

    qs("#testLoginBtn").addEventListener("click", () => {
      goToLoginForTest();
    });
  }

  function renderTestSetup(autoOpen = false) {
    root.innerHTML = `
      <div class="test-stepper">
        <span class="active">1. Chọn ngôn ngữ</span>
        <span>2. Chọn trình độ</span>
        <span>3. Làm bài test</span>
        <span>4. Xem kết quả</span>
      </div>

      <div class="test-setup-grid">
        <div class="test-setup-form">
          <label class="test-label">
            <span>Ngôn ngữ</span>
            <select id="testLanguage">
              ${[...new Set(tests.map(test => test.language))].map(language =>
                `<option value="${esc(language)}">${esc(language)}</option>`
              ).join("")}
            </select>
          </label>

          <label class="test-label">
            <span>Trình độ</span>
            <select id="testLevel"></select>
          </label>

          <button class="btn primary" id="startTestBtn" type="button">
            Bắt đầu làm bài →
          </button>

          <p class="test-note">Bạn đã đăng nhập với tài khoản <strong>${esc(user.name || user.email)}</strong>.</p>
        </div>

        <div class="test-preview-card">
          <img class="test-preview-image" src="../../IMG/course-english.png" alt="Bài test tiếng Anh">
          <div class="test-preview-badge">YUNA TEST</div>
          <h3>Kiểm tra trình độ</h3>
          <p>Chọn ngôn ngữ và trình độ phù hợp trước khi bắt đầu.</p>
          <div class="test-preview-meta">
            <span>⏱ Thời gian: <b id="testDuration">15 phút</b></span>
            <span>✓ Câu hỏi: <b id="testCount">3 câu</b></span>
          </div>
        </div>
      </div>

      <div id="testWrap"></div>`;

    const languageSelect = qs("#testLanguage");
    const levelSelect = qs("#testLevel");

    function updateLevels() {
      const selectedLanguage = languageSelect.value;
      const languageTests = tests.filter(test => test.language === selectedLanguage);
      levelSelect.innerHTML = [...new Set(languageTests.map(test => test.level))]
        .map(level => `<option value="${esc(level)}">${esc(level)}</option>`)
        .join("");
      updateMeta();
    }

    function selectedTest() {
      return tests.find(test =>
        test.language === languageSelect.value && test.level === levelSelect.value
      ) || tests.find(test => test.language === languageSelect.value) || tests[0];
    }

    function updateMeta() {
      const test = selectedTest();
      qs("#testDuration").textContent = `${test.durationMinutes} phút`;
      qs("#testCount").textContent = `${test.questions.length} câu`;
    }

    languageSelect.addEventListener("change", updateLevels);
    levelSelect.addEventListener("change", updateMeta);
    qs("#startTestBtn").addEventListener("click", () => renderQuestions(selectedTest()));

    updateLevels();

    if (autoOpen) {
      // Sau khi đăng nhập, người dùng vẫn được quyền đổi ngôn ngữ/trình độ trước khi làm.
      qs("#startTestBtn")?.focus();
    }
  }

  function renderQuestions(test) {
    qs("#testWrap").innerHTML = `
      <div class="test-running-head">
        <div>
          <span class="eyebrow">${esc(test.language)} · ${esc(test.level)}</span>
          <h3>${esc(test.title)}</h3>
        </div>
        <span class="test-time">⏱ ${test.durationMinutes} phút</span>
      </div>

      <form id="onlineTestForm" class="form-card">
        ${test.questions.map((question, index) => `
          <div class="test-question">
            <strong>${index + 1}. ${esc(question.q)}</strong>
            <div class="test-answers">
              ${question.answers.map((answer, answerIndex) => `
                <label>
                  <input type="radio" name="q${index}" value="${answerIndex}" required>
                  <span>${esc(answer)}</span>
                </label>`).join("")}
            </div>
          </div>`).join("")}

        <button class="btn primary" type="submit">Nộp bài & chấm điểm</button>
        <div id="testResult"></div>
      </form>`;

    qs("#onlineTestForm").addEventListener("submit", event => {
      event.preventDefault();

      const current = currentUser();
      if (!current) {
        goToLoginForTest();
        return;
      }

      const formData = new FormData(event.currentTarget);
      let correct = 0;
      test.questions.forEach((question, index) => {
        if (Number(formData.get(`q${index}`)) === question.correct) correct++;
      });

      const score = Math.round(correct / test.questions.length * 100);
      const data = getData();

      if (current.role === "student" && current.studentId) {
        data.testResults.unshift({
          id: uid("res-"),
          testId: test.id,
          studentId: current.studentId,
          score,
          correct,
          total: test.questions.length,
          createdAt: today()
        });
        saveData(data);
      }

      qs("#testResult").innerHTML = `
        <div class="result-box">
          <strong>${score}/100</strong>
          <span>Đúng ${correct}/${test.questions.length} câu. ${current.role === "student" ? "Kết quả đã được lưu vào hồ sơ." : "Kết quả được hiển thị cho tài khoản hiện tại."}</span>
        </div>`;
    });
  }
});
