
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#noticeList");
  if (!root) return;

  const user = currentUser();
  if (!user) {
    location.href = "index.html";
    return;
  }

  if (user.role === "student" && !hasEnrollment(user.studentId)) {
    root.innerHTML = `<div class="notice-inline">Bạn chưa đăng ký khóa học nên chưa mở khu vực thông báo học viên.</div>`;
    return;
  }

  const notices = getData().notifications.filter(n =>
    user.role !== "student" || studentHasNotification(user.studentId, n)
  );

  root.innerHTML = notices.length
    ? notices.map(n => `
        <article class="notice">
          <small>${fmtDate(n.createdAt)}</small>
          <h3>${esc(n.title)}</h3>
          <p>${esc(n.content)}</p>
        </article>`).join("")
    : `<div class="notice-inline">Chưa có thông báo.</div>`;
});
