
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#teacherSchedule");
  if (!root) return;

  const user = currentUser();
  if (!user || user.role !== "teacher") {
    location.href = "index.html";
    return;
  }

  const data = getData();
  const rows = data.classes.filter(c => c.teacherId === user.teacherId);

  root.innerHTML = rows.length
    ? rows.map(c => {
        const course = courseById(c.courseId);
        const count = data.enrollments.filter(e => e.classId === c.id && e.status !== "cancelled").length;

        return `
          <article class="schedule-card">
            <div>
              <h3>${esc(c.name)} · ${esc(course?.name || "")}</h3>
              <p>${esc(c.schedule)}<br>Phòng: ${esc(c.room)} · ${esc(c.format)}<br>${count}/${c.capacity} học viên</p>
            </div>
            <div><span class="status">Khai giảng ${fmtDate(c.startDate)}</span></div>
          </article>`;
      }).join("")
    : `<div class="notice-inline">Chưa có lịch dạy.</div>`;
});
