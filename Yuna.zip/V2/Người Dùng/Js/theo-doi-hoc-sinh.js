
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#trackingArea");
  if (!root) return;

  const user = currentUser();
  if (!user || user.role !== "teacher") {
    location.href = "index.html";
    return;
  }

  render();

  function render() {
    const data = getData();
    const classes = data.classes.filter(c => c.teacherId === user.teacherId);
    const enrollments = data.enrollments.filter(e =>
      classes.some(c => c.id === e.classId) && e.status !== "cancelled"
    );

    if (!enrollments.length) {
      root.innerHTML = `<div class="notice-inline">Chưa có học viên trong các lớp bạn phụ trách.</div>`;
      return;
    }

    root.innerHTML = `<div class="tracking-grid">${enrollments.map(e => {
      const student = studentById(e.studentId);
      const cls = classById(e.classId);
      const course = courseById(e.courseId);
      const records = data.attendance.filter(a => a.studentId === e.studentId && a.classId === e.classId);
      const attended = records.filter(a => ["present","late"].includes(a.status)).length;
      const rate = records.length ? Math.round(attended / records.length * 100) : 0;

      return `
        <article class="tracking-card">
          <h3>${esc(student?.name || "Học viên")}</h3>
          <p>${esc(course?.name || "")} · ${esc(cls?.name || "")}</p>

          <div class="metric-row">
            <div class="metric"><b>${e.progress || 0}%</b><span>Tiến độ</span></div>
            <div class="metric"><b>${rate}%</b><span>Tham dự</span></div>
            <div class="metric"><b>${records.length}</b><span>Số buổi</span></div>
          </div>

          <div class="progress"><span style="width:${Math.max(2, e.progress || 0)}%"></span></div>
          <button class="btn ghost small" data-note="${e.id}" style="margin-top:9px">Ghi nhận xét</button>
        </article>`;
    }).join("")}</div>`;

    root.querySelectorAll("[data-note]").forEach(button => {
      button.addEventListener("click", () => {
        const note = prompt("Nhập nhận xét / mục cần hỗ trợ:", "");
        if (note === null) return;

        const d = getData();
        const e = d.enrollments.find(item => item.id === button.dataset.note);
        if (!e) return;

        e.teacherNote = note;
        d.notifications.unshift({
          id: uid("n-"),
          title: "Cập nhật theo dõi học tập",
          content: note,
          audience: "student",
          targetId: e.studentId,
          createdAt: today()
        });

        saveData(d);
        render();
      });
    });
  }
});
