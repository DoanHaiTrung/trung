document.addEventListener("DOMContentLoaded", () => {
  const list = qs("#courseList");

  if (!list) return;

  const filters = {
    search: qs("#courseSearch"),
    language: qs("#languageFilter"),
    level: qs("#levelFilter"),
    duration: qs("#durationFilter"),
    format: qs("#formatFilter"),
    certificate: qs("#certificateFilter")
  };

  const count = qs("#courseCount");
  const courses = getData().courses.filter(course => course.active !== false);

  const languages = [...new Set(courses.map(course => course.language).filter(Boolean))];
  const levels = [...new Set(courses.map(course => course.level).filter(Boolean))];
  const certificateTypes = [
    ...new Set(courses.filter(course => course.certificate).map(course => course.certificateName).filter(Boolean))
  ];

  languages.forEach(value => {
    filters.language.insertAdjacentHTML(
      "beforeend",
      `<option value="${esc(value)}">${esc(value)}</option>`
    );
  });

  levels.forEach(value => {
    filters.level.insertAdjacentHTML(
      "beforeend",
      `<option value="${esc(value)}">${esc(value)}</option>`
    );
  });

  certificateTypes.forEach(value => {
    filters.certificate.insertAdjacentHTML(
      "beforeend",
      `<option value="${esc(value)}">${esc(value)}</option>`
    );
  });

  function render() {
    const keyword = String(filters.search?.value || "").trim().toLowerCase();

    const filtered = courses.filter(course => {
      const text = `${course.name} ${course.language} ${course.level} ${course.desc}`.toLowerCase();
      const keywordOk = !keyword || text.includes(keyword);
      const languageOk = !filters.language.value || course.language === filters.language.value;
      const levelOk = !filters.level.value || course.level === filters.level.value;
      const durationOk = !filters.duration.value || course.durationGroup === filters.duration.value;
      const formatOk = !filters.format.value || course.format === filters.format.value;
      const certificateOk = !filters.certificate.value
        || (filters.certificate.value === "none" && !course.certificate)
        || (course.certificate && course.certificateName === filters.certificate.value);

      return keywordOk && languageOk && levelOk && durationOk && formatOk && certificateOk;
    });

    count.textContent = `${filtered.length} khóa học`;

    list.innerHTML = filtered.length
      ? filtered.map(courseCard).join("")
      : `<div class="empty">Không tìm thấy khóa học phù hợp. Hãy thử đổi bộ lọc.</div>`;
  }

  function courseCard(course) {
    return `
      <article class="course-card">
        <div class="course-card-image">
          <img src="${course.image}" alt="${esc(course.name)}">
          <span class="format-badge">${esc(course.format)}</span>
        </div>

        <div class="course-content">
          <div class="course-tags">
            <span>${esc(course.language)}</span>
            <span>${esc(course.level)}</span>
          </div>

          <h3>${esc(course.name)}</h3>
          <p>${esc(course.desc)}</p>

          <div class="course-info">
            <div>⏱ <b>${esc(course.duration)}</b></div>
            <div>🎓 <b>${course.certificate ? esc(course.certificateName || "Có") : "Không"}</b></div>
            <div>🖥 <b>${esc(course.format)}</b></div>
          </div>

          <div class="course-bottom">
            <strong>${money(course.price)}</strong>
            <a class="btn primary small" href="chi-tiet-khoa-hoc.html?id=${encodeURIComponent(course.id)}">
              Xem chi tiết →
            </a>
          </div>
        </div>
      </article>`;
  }

  qsa(".course-filter select").forEach(select => {
    select.addEventListener("change", render);
  });

  filters.search?.addEventListener("input", render);

  qs("#resetFilters")?.addEventListener("click", () => {
    filters.search.value = "";
    qsa(".course-filter select").forEach(select => {
      select.value = "";
    });
    render();
  });

  render();
});
