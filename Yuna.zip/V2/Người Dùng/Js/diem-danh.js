
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#attendanceArea");
  if (!root) return;

  const user = currentUser();
  if (!user || user.role !== "teacher") {
    location.href = "index.html";
    return;
  }

  const data = getData();
  const classes = data.classes.filter(c => c.teacherId === user.teacherId);

  if (!classes.length) {
    root.innerHTML = `<div class="notice-inline">Bạn chưa được phân công lớp.</div>`;
    return;
  }

  qs("#attendanceClass").innerHTML = classes.map(c =>
    `<option value="${c.id}">${esc(c.name)} · ${esc(courseById(c.courseId)?.name || "")}</option>`
  ).join("");

  qs("#attendanceDate").value = today();

  render();

  qs("#attendanceClass").addEventListener("change", render);
  qs("#attendanceDate").addEventListener("change", render);

  qs("#saveAttendance").addEventListener("click", () => {
    const classId = qs("#attendanceClass").value;
    const date = qs("#attendanceDate").value;
    const students = data.enrollments.filter(e => e.classId === classId && e.status !== "cancelled");

    students.forEach(e => {
      const select = qs(`[data-attendance-student="${e.studentId}"]`);
      const existing = data.attendance.find(a =>
        a.classId === classId && a.studentId === e.studentId && a.date === date
      );

      const record = {
        id: existing?.id || uid("att-"),
        classId,
        studentId: e.studentId,
        date,
        status: select?.value || "present",
        teacherId: user.teacherId
      };

      const index = data.attendance.findIndex(a => a.id === record.id);
      if (index >= 0) data.attendance[index] = record;
      else data.attendance.push(record);
    });

    saveData(data);
    addActivity(`${user.name} cập nhật điểm danh ${date}`);
    qs("#attendanceMessage").textContent = `Đã lưu điểm danh ${fmtDate(date)}.`;
    render();
  });

  function render() {
    const classId = qs("#attendanceClass").value;
    const date = qs("#attendanceDate").value;
    const students = data.enrollments.filter(e => e.classId === classId && e.status !== "cancelled");

    root.innerHTML = students.length
      ? `<div class="check-grid">${students.map(e => {
          const student = studentById(e.studentId);
          const record = data.attendance.find(a =>
            a.classId === classId && a.studentId === e.studentId && a.date === date
          );

          return `
            <article class="student-check">
              <strong>${esc(student?.name || e.studentId)}</strong>
              <small>${esc(student?.phone || "")}</small>
              <select data-attendance-student="${e.studentId}">
                <option value="present" ${record?.status === "present" ? "selected" : ""}>Có mặt</option>
                <option value="late" ${record?.status === "late" ? "selected" : ""}>Đi muộn</option>
                <option value="absent" ${record?.status === "absent" ? "selected" : ""}>Vắng</option>
                <option value="excused" ${record?.status === "excused" ? "selected" : ""}>Có phép</option>
              </select>
            </article>`;
        }).join("")}</div>`
      : `<div class="notice-inline">Lớp chưa có học viên.</div>`;
  }
});
