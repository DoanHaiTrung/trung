
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#myCourses");
  if (!root) return;

  const user = currentUser();
  if (!user || user.role !== "student") {
    location.href = "index.html";
    return;
  }

  const enrollments = myEnrollments(user.studentId);
  if (!enrollments.length) {
    root.innerHTML = `<div class="notice-inline">Bạn chưa đăng ký khóa học.</div>`;
    return;
  }

  root.innerHTML = enrollments.map(e => {
    const course = courseById(e.courseId);
    const cls = classById(e.classId);
    const progress = Math.max(0, Math.min(100, Number(e.progress) || 0));

    return `
      <article class="my-course">
        <img src="${course?.image || "../../IMG/course-english.png"}" alt="${esc(course?.name || "")}">
        <div>
          <span>${esc(course?.language || "")} · ${esc(course?.format || "")}</span>
          <h3>${esc(course?.name || "Khóa học")}</h3>
          <p>${esc(course?.duration || "")}<br>Lớp: ${esc(cls?.name || "Chưa xếp lớp")}</p>
          <p>${esc(cls?.schedule || course?.schedule || "")}</p>
          <strong>Tiến độ ${progress}%</strong>
          <div class="progress"><span style="width:${progress}%"></span></div>
          <button class="btn ghost small" data-progress="${e.id}" style="margin-top:9px">Cập nhật tiến độ</button>
        </div>
      </article>`;
  }).join("");

  root.addEventListener("click", e => {
    const btn = e.target.closest("[data-progress]");
    if (!btn) return;

    const value = prompt("Nhập tiến độ 0–100:", "0");
    if (value === null) return;

    const progress = Math.max(0, Math.min(100, Number(value) || 0));
    const data = getData();
    const item = data.enrollments.find(x => x.id === btn.dataset.progress);
    if (item) item.progress = progress;
    saveData(data);
    location.reload();
  });
});
