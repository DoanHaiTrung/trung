
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#studentSchedule");
  if (!root) return;

  const user = currentUser();
  if (!user || user.role !== "student") {
    location.href = "index.html";
    return;
  }

  const rows = myEnrollments(user.studentId);

  root.innerHTML = rows.length
    ? rows.map(e => {
        const course = courseById(e.courseId);
        const cls = classById(e.classId);
        const teacher = teacherById(cls?.teacherId);

        return `
          <article class="schedule-card">
            <div>
              <h3>${esc(course?.name || "Khóa học")}</h3>
              <p>
                <b>Lớp:</b> ${esc(cls?.name || "Chưa xếp lớp")}<br>
                <b>Giáo viên:</b> ${esc(teacher?.name || "Đang phân công")}<br>
                <b>Hình thức:</b> ${esc(cls?.format || course?.format || "")}<br>
                <b>Phòng:</b> ${esc(cls?.room || "—")}
              </p>
            </div>
            <div>
              <span class="status">${esc(cls?.schedule || course?.schedule || "Chưa có lịch")}</span>
              <small style="display:block;margin-top:7px;color:#809da7;font-size:7px">
                Khai giảng: ${fmtDate(cls?.startDate)}
              </small>
            </div>
          </article>`;
      }).join("")
    : `<div class="notice-inline">Bạn chưa có khóa học nên chưa có lịch học.</div>`;
});
