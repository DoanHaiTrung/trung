document.addEventListener("DOMContentLoaded",()=>{
  const box=qs("#coursePreview");
  if(!box)return;
  const data=getData();
  box.innerHTML=data.courses.filter(c=>c.active!==false).slice(0,4).map(c=>`
    <article class="home-course-card">
      <img src="${c.image}" alt="${esc(c.name)}">
      <div class="card-body">
        <span class="tag">${esc(c.language)}</span>
        <h3>${esc(c.name)}</h3>
        <p>${esc(c.desc)}</p>
        <div class="card-actions">
          <strong class="price">${money(c.price)}</strong>
          <a class="btn primary small" href="chi-tiet-khoa-hoc.html?id=${encodeURIComponent(c.id)}">Xem chi tiết →</a>
        </div>
      </div>
    </article>`).join("");
});
