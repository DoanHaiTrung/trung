
document.addEventListener("DOMContentLoaded", () => {
  const form = qs("#leaveForm");
  if (!form) return;

  const user = currentUser();
  if (!user || !["student","teacher"].includes(user.role)) {
    location.href = "index.html";
    return;
  }

  const select = qs("#leaveCourse");
  const isStudent = user.role === "student";

  qs("#leaveTitle").textContent = isStudent ? "Đơn xin nghỉ học" : "Mẫu đơn xin nghỉ của giáo viên";
  qs("#leaveHint").textContent = isStudent
    ? (hasEnrollment(user.studentId)
        ? "Chọn khóa học, ngày và lý do. Đơn sẽ chuyển về quản trị để xử lý."
        : "Bạn chưa đăng ký khóa học nên chưa thể gửi đơn nghỉ học.")
    : "Mẫu dùng cho giáo viên xin nghỉ, xin đổi lịch hoặc xin học bù.";

  if (isStudent) {
    select.innerHTML = myEnrollments(user.studentId).map(e =>
      `<option value="${e.id}">${esc(courseById(e.courseId)?.name || "")}</option>`
    ).join("") || `<option value="">Chưa có khóa học</option>`;

    if (!hasEnrollment(user.studentId)) qs("#leaveSubmit").disabled = true;
  } else {
    select.innerHTML = getData().classes
      .filter(c => c.teacherId === user.teacherId)
      .map(c => `<option value="${c.id}">${esc(c.name)} · ${esc(courseById(c.courseId)?.name || "")}</option>`)
      .join("") || `<option value="">Chưa có lớp</option>`;
  }

  qs("#leaveDate").value = today();

  form.addEventListener("submit", e => {
    e.preventDefault();

    const fd = new FormData(form);
    const data = getData();

    data.leaveRequests.unshift({
      id: uid("leave-"),
      requesterId: isStudent ? user.studentId : user.teacherId,
      requesterRole: user.role,
      courseOrClassId: String(fd.get("courseOrClassId") || ""),
      date: String(fd.get("date") || ""),
      type: String(fd.get("type") || "Xin nghỉ"),
      reason: String(fd.get("reason") || "").trim(),
      status: "Chờ duyệt",
      createdAt: today()
    });

    saveData(data);
    addActivity(`${user.name} gửi ${fd.get("type") || "đơn nghỉ"}`);
    form.reset();
    qs("#leaveDate").value = today();
    qs("#leaveMessage").textContent = "Đã gửi đơn. Trạng thái: Chờ duyệt.";
    renderHistory();
  });

  renderHistory();

  function renderHistory() {
    const rows = getData().leaveRequests.filter(r =>
      r.requesterId === (isStudent ? user.studentId : user.teacherId)
    );

    qs("#leaveHistory").innerHTML = rows.length
      ? rows.map(r => `
          <div class="schedule-card">
            <div><h3>${esc(r.type)}</h3><p>${fmtDate(r.date)} · ${esc(r.reason)}</p></div>
            <span class="status">${esc(r.status)}</span>
          </div>`).join("")
      : `<div class="notice-inline">Chưa có đơn nào.</div>`;
  }
});
