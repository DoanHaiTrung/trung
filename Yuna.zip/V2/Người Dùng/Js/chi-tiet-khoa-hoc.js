
document.addEventListener("DOMContentLoaded", () => {
  const root = qs("#courseDetail");
  if (!root) return;

  const id = new URLSearchParams(location.search).get("id") || "c-eng";
  const course = courseById(id) || getData().courses[0];
  const user = currentUser();

  const already = user?.role === "student"
    && myEnrollments(user.studentId).some(e => e.courseId === course.id);

  const classes = getData().classes.filter(c =>
    c.courseId === course.id && c.status !== "Đã đóng"
  );

  root.innerHTML = `
    <div class="detail-shell">
      <div class="detail-image">
        <img src="${course.image}" alt="${esc(course.name)}">
      </div>

      <div class="detail-main">
        <span class="eyebrow">${esc(course.language)} · ${esc(course.level)}</span>
        <h1 class="course-detail-title">${esc(course.name)}</h1>
        <p class="lead">${esc(course.desc)}</p>

        <div class="detail-stats">
          <div><small>Thời lượng</small><strong>${esc(course.duration)}</strong></div>
          <div><small>Hình thức</small><strong>${esc(course.format)}</strong></div>
          <div><small>Chứng chỉ</small><strong>${course.certificate ? esc(course.certificateName || "Có") : "Không"}</strong></div>
          <div><small>Học phí</small><strong>${money(course.price)}</strong></div>
        </div>

        <div class="detail-block">
          <h3>Lịch học dự kiến</h3>
          <p>${esc(course.schedule)}</p>
        </div>

        <div class="detail-block">
          <h3>Lớp đang mở</h3>
          <div class="class-list">
            ${
              classes.length
                ? classes.map(c => {
                    const teacher = teacherById(c.teacherId);
                    return `
                      <div>
                        <b>${esc(c.name)}</b>
                        <span>
                          ${esc(c.format)} · ${esc(c.room)}<br>
                          GV ${esc(teacher?.name || "Chưa phân công")}<br>
                          ${esc(c.schedule)}
                        </span>
                      </div>`;
                  }).join("")
                : `<div><b>Đang cập nhật</b><span>Liên hệ để được xếp lớp.</span></div>`
            }
          </div>
        </div>

        <div class="detail-block">
          <ul>
            <li>Theo dõi lịch, thông báo và tiến độ ngay trên website.</li>
            <li>Giáo viên điểm danh và cập nhật nhận xét theo từng buổi.</li>
            <li>Học viên có biểu mẫu xin nghỉ/đổi lịch.</li>
          </ul>
        </div>

        <div class="enroll-box">
          <div>
            <small>Học phí</small>
            <strong>${money(course.price)}</strong>
          </div>
          <div>
            ${
              already
                ? `<a class="btn ghost" href="khoa-hoc-cua-toi.html">Đã đăng ký · Xem khóa học</a>`
                : `<button class="btn primary" id="enrollBtn">Đăng ký khóa học →</button>`
            }
          </div>
        </div>

        <div id="enrollMessage" class="notice-line"></div>
      </div>
    </div>`;

  qs("#enrollBtn")?.addEventListener("click", () => {
    const current = currentUser();

    if (!current) {
      window.AccountUI?.open("login", course.id);
      return;
    }
    if (current.role !== "student") {
      qs("#enrollMessage").textContent = "Chỉ tài khoản học viên mới đăng ký khóa học.";
      return;
    }

    openPaymentQR(current);
  });

  function openPaymentQR(current) {
    const existing = document.querySelector("#paymentQrModal");
    if (existing) existing.remove();

    const modal = document.createElement("div");
    modal.id = "paymentQrModal";
    modal.className = "payment-qr-modal";
    modal.innerHTML = `
      <div class="payment-qr-backdrop" data-close-payment></div>
      <div class="payment-qr-dialog" role="dialog" aria-modal="true" aria-labelledby="paymentQrTitle">
        <button class="payment-qr-close" type="button" aria-label="Đóng" data-close-payment>×</button>
        <div class="payment-qr-head">
          <span class="payment-qr-eyebrow">THANH TOÁN KHÓA HỌC</span>
          <h2 id="paymentQrTitle">Quét mã QR để đăng ký</h2>
          <p>Đăng nhập thành công. Vui lòng quét mã QR bên dưới để thanh toán học phí <strong>${money(course.price)}</strong>.</p>
        </div>
        <div class="payment-qr-image-wrap">
          <img src="../../IMG/qr-thanh-toan-vietcombank.png" alt="Mã QR thanh toán Vietcombank">
        </div>
        <div class="payment-qr-info">
          <strong>${esc(current.name || "Học viên")}</strong>
          <span>${esc(course.name)}</span>
        </div>
        <div class="payment-qr-actions">
          <button type="button" class="btn ghost" data-close-payment>Đóng</button>
          <button type="button" class="btn primary" id="confirmPaymentBtn">Đã thanh toán · Hoàn tất đăng ký</button>
        </div>
        <small class="payment-qr-note">Sau khi bạn xác nhận, hệ thống sẽ ghi nhận đăng ký khóa học trên website. Đây không phải là xác nhận thanh toán tự động từ ngân hàng.</small>
      </div>`;

    document.body.appendChild(modal);
    document.body.classList.add("payment-modal-open");

    modal.querySelectorAll("[data-close-payment]").forEach(el =>
      el.addEventListener("click", closePaymentQR)
    );
    modal.querySelector("#confirmPaymentBtn")?.addEventListener("click", () => {
      closePaymentQR();
      enrollStudent(current.studentId);
    });
  }

  function closePaymentQR() {
    document.querySelector("#paymentQrModal")?.remove();
    document.body.classList.remove("payment-modal-open");
  }

  function enrollStudent(studentId) {
    const data = getData();

    if (data.enrollments.some(e =>
      e.studentId === studentId && e.courseId === course.id && e.status !== "cancelled"
    )) {
      qs("#enrollMessage").textContent = "Bạn đã đăng ký khóa học này.";
      return;
    }

    const openClass = data.classes.find(c =>
      c.courseId === course.id && c.status !== "Đã đóng"
    );

    data.enrollments.push({
      id: uid("enr-"),
      studentId,
      courseId: course.id,
      classId: openClass?.id || "",
      status: "approved",
      registeredAt: today(),
      progress: 0
    });

    const student = studentById(studentId);
    if (student) student.status = "Đang học";

    data.notifications.unshift({
      id: uid("n-"),
      title: "Đăng ký khóa học thành công",
      content: `Bạn đã đăng ký ${course.name}.`,
      audience: "student",
      targetId: studentId,
      createdAt: today()
    });

    data.activity.unshift(`${student?.name || currentUser().name} đăng ký ${course.name}`);
    saveData(data);

    qs("#enrollMessage").textContent =
      "Đăng ký thành công. Menu tài khoản đã mở thêm Khóa học của tôi, Lịch học, Thông báo và Xin nghỉ.";

    buildHeader();
  }
});
