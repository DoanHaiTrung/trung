(function () {
  function modal() {
    let element = qs("#accountModal");

    if (element) return element;

    element = document.createElement("div");
    element.id = "accountModal";
    element.className = "account-modal";

    element.innerHTML = `
      <section class="account-dialog">
        <button class="account-close" type="button" data-close-account>×</button>

        <div class="account-decoration">
          <img src="../../IMG/logo-merimaid.jpg" alt="Yuna Language Center">
        </div>
        <div class="account-welcome">Chào mừng trở lại Yuna</div>

        <div class="account-tabs">
          <button class="active" data-account-tab="login">👤 Đăng nhập</button>
          <button data-account-tab="register">＋ Đăng ký</button>
        </div>

        <div id="accountMessage" class="account-message"></div>

        <form id="loginForm">
          <label class="account-field">
            <span>Email</span>
            <input name="email" autocomplete="username" required>
          </label>

          <label class="account-field">
            <span>Mật khẩu</span>
            <div class="password-row">
              <input name="password" type="password" autocomplete="current-password" required>
              <button type="button" data-show-login>Hiện</button>
            </div>
          </label>

          <div class="account-options">
            <label>
              <input type="checkbox" id="showLoginPassword">
              Hiện mật khẩu
            </label>
            <button type="button" class="link-button" data-forgot>Quên mật khẩu?</button>
          </div>

          <button class="account-submit">
            Đăng nhập <span>→</span>
          </button>

          <p class="account-foot">
            Chưa có tài khoản?
            <button type="button" data-account-tab="register">Đăng ký ngay</button>
          </p>
        </form>

        <form id="registerForm" class="hidden">
          <label class="account-field">
            <span>Họ và tên</span>
            <input name="name" required>
          </label>

          <label class="account-field">
            <span>Email</span>
            <input name="email" type="email" required>
          </label>

          <label class="account-field">
            <span>Số điện thoại</span>
            <input name="phone" required>
          </label>

          <div class="account-two-col">
            <label class="account-field">
              <span>Ngôn ngữ</span>
              <select name="language">
                <option>Tiếng Anh</option>
                <option>Tiếng Hàn</option>
                <option>Tiếng Trung</option>
                <option>Tiếng Nhật</option>
              </select>
            </label>

            <label class="account-field">
              <span>Mục tiêu</span>
              <select name="goal">
                <option>Giao tiếp</option>
                <option>Luyện thi</option>
                <option>Công việc</option>
                <option>Du học</option>
              </select>
            </label>
          </div>

          <label class="account-field">
            <span>Mật khẩu</span>
            <div class="password-row">
              <input name="password" type="password" minlength="6" required>
              <button type="button" data-show-reg>Hiện</button>
            </div>
          </label>

          <label class="account-check">
            <input type="checkbox" required>
            Tôi đồng ý với quy định đăng ký.
          </label>

          <button class="account-submit">
            Tạo tài khoản <span>→</span>
          </button>

          <p class="account-foot">
            Đã có tài khoản?
            <button type="button" data-account-tab="login">Đăng nhập</button>
          </p>
        </form>
      </section>`;

    document.body.appendChild(element);
    bind(element);
    return element;
  }

  function message(text, type = "") {
    const box = qs("#accountMessage");

    if (!box) return;

    box.textContent = text;
    box.className = "account-message " + type;
  }

  function tab(name) {
    const element = modal();
    const register = name === "register";

    element.querySelectorAll("[data-account-tab]").forEach(button => {
      button.classList.toggle("active", button.dataset.accountTab === name);
    });

    qs("#loginForm", element).classList.toggle("hidden", register);
    qs("#registerForm", element).classList.toggle("hidden", !register);
    message("");
  }

  function open(name = "login", pendingCourse = "") {
    const element = modal();

    if (pendingCourse) {
      localStorage.setItem(MK.pending, pendingCourse);
    }

    tab(name);
    element.classList.add("open");

    setTimeout(() => {
      qs(name === "login" ? "#loginForm input" : "#registerForm input")?.focus();
    }, 60);
  }

  function close() {
    qs("#accountModal")?.classList.remove("open");
  }

  function postAuth() {
    const pendingCourse = localStorage.getItem(MK.pending);

    if (pendingCourse) {
      localStorage.removeItem(MK.pending);
      location.href = `chi-tiet-khoa-hoc.html?id=${encodeURIComponent(pendingCourse)}`;
      return;
    }

    if (localStorage.getItem(MK.pendingTest) === "1") {
      localStorage.removeItem(MK.pendingTest);
      location.href = "bai-test.html?start=1";
      return;
    }

    if (location.pathname.split("/").pop() !== "index.html") {
      location.href = "index.html";
      return;
    }

    close();
    buildHeader();
  }

  function bind(element) {
    element.addEventListener("click", event => {
      const tabButton = event.target.closest("[data-account-tab]");

      if (tabButton) {
        tab(tabButton.dataset.accountTab);
      }

      if (event.target.closest("[data-close-account]")) {
        close();
      }

      if (event.target.closest("[data-forgot]")) {
        message("Demo: hãy liên hệ trung tâm để đặt lại mật khẩu.", "info");
      }

      const loginShow = event.target.closest("[data-show-login]");

      if (loginShow) {
        const input = qs('input[name="password"]', qs("#loginForm"));
        input.type = input.type === "password" ? "text" : "password";
      }

      const registerShow = event.target.closest("[data-show-reg]");

      if (registerShow) {
        const input = qs('input[name="password"]', qs("#registerForm"));
        input.type = input.type === "password" ? "text" : "password";
      }
    });

    qs("#showLoginPassword", element)?.addEventListener("change", event => {
      const input = qs('input[name="password"]', qs("#loginForm"));
      input.type = event.target.checked ? "text" : "password";
    });

    qs("#loginForm", element).addEventListener("submit", event => {
      event.preventDefault();

      const formData = new FormData(event.currentTarget);
      const email = String(formData.get("email")).trim().toLowerCase();
      const password = String(formData.get("password"));
      let account = getAccounts().find(item => {
        return String(item.email).trim().toLowerCase() === email && String(item.password) === password;
      });

      // Luôn bảo đảm tài khoản quản trị mặc định có thể đăng nhập ngay cả khi
      // localStorage của trình duyệt đang chứa dữ liệu cũ từ phiên bản trước.
      if (!account && email === "admin@gmail.com" && password === "Mduyen952004") {
        account = {
          email: "admin@gmail.com",
          password: "Mduyen952004",
          name: "Vũ Thị Mỹ Duyên",
          role: "admin"
        };
        const accounts = getAccounts();
        const index = accounts.findIndex(item => String(item.email).toLowerCase() === email);
        if (index >= 0) accounts[index] = account;
        else accounts.push(account);
        saveAccounts(accounts);
      }

      if (!account) {
        message("Email hoặc mật khẩu chưa đúng.", "error");
        return;
      }

      setUser(account);
      addActivity(`${account.name} đăng nhập (${roleName(account.role)})`);

      if (["admin", "staff", "accountant"].includes(account.role)) {
        location.href = "../../Quan Tri/quan-tri.html";
        return;
      }

      postAuth();
    });

    qs("#registerForm", element).addEventListener("submit", event => {
      event.preventDefault();

      const formData = new FormData(event.currentTarget);
      const accounts = getAccounts();
      const email = String(formData.get("email")).trim().toLowerCase();

      if (accounts.some(account => account.email.toLowerCase() === email)) {
        message("Email đã tồn tại. Hãy đăng nhập.", "error");
        return;
      }

      const data = getData();
      const student = {
        id: uid("stu-"),
        name: String(formData.get("name")).trim(),
        email,
        phone: String(formData.get("phone")).trim(),
        language: String(formData.get("language")),
        goal: String(formData.get("goal")),
        status: "Chưa đăng ký khóa học",
        joinedAt: today()
      };
      const account = {
        email,
        password: String(formData.get("password")),
        name: student.name,
        role: "student",
        studentId: student.id
      };

      data.students.push(student);
      accounts.push(account);

      saveData(data);
      saveAccounts(accounts);
      setUser(account);
      addActivity(`${account.name} tạo tài khoản học viên`);
      postAuth();
    });
  }

  function logout() {
    const user = currentUser();

    clearUser();
    localStorage.removeItem(MK.pending);

    if (user) {
      addActivity(`${user.name} đăng xuất`);
    }

    if (location.pathname.split("/").pop() !== "index.html") {
      location.href = "index.html";
      return;
    }

    buildHeader();
  }

  window.AccountUI = {
    open,
    close,
    logout
  };

  document.addEventListener("DOMContentLoaded", () => {
    document.body.addEventListener("click", event => {
      const trigger = event.target.closest("[data-open-account]");

      if (trigger) {
        open(trigger.dataset.openAccount || "login");
      }
    });

    if (location.hash === "#account") {
      setTimeout(() => open("login"), 120);
    }
  });
})();
